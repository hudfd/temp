# 从零看懂：这个项目里 JSP ↔ Action ↔ Service 是怎么"拼"起来的

> 适用仓库：`E:/agent/pi/day1109/ebid`
> 本文不讲理论，只讲**这个项目实际是怎么写的**，每一步都贴真实代码 + 行号，你可以边看边打开文件核对。
> 建议顺序：先看第 1 章的"全景图"，再照着第 2 章的例子**完整走一遍**，最后用第 4 章的 SOP 自己查任意页面。

---

## 1. 全景图：一次请求会经过 6 个"映射表"

这个项目是 Struts 1 + 自研框架（wakaba/rug）。**所有跳转和取数，都是查表**。
一共 6 张表，全部是 XML/Java 里的配置，没有魔法：

```
浏览器 JS 拼 URL
   │  ① URL → Action
   ▼
struts-config.xml          <action path="/xxx.do" >  <forward name="A" path="页面或tiles定义"/>
   │  ② Action → Service 名
   ▼
action-service.xml         <action name="/xxx"> <servicename value="XxxService"/> </action>
   │  ③ Service 名 → Java 类（约定：类名同名）
   ▼
XxxService.execute()        干活：Entity → SQL → DB
   │  ④ 把结果放进 request（key）        ⑤ 返回 forward 名
   ▼                                        │
request.setAttribute(key, ...)              │
                                            ▼
                                     ⑥ forward 名 → 页面（回到 struts-config 的 <forward>）
                                            ▼
                                     JSP 里 <bean:write name="key"> 取数据
```

**记这三句话就够了：**

1. **URL 找 Action**：靠 `struts-config.xml` 的 `path`
2. **Action 找 Service**：靠 `action-service.xml`（同一个 `name`，一一对应）
3. **Service 的结果给 JSP**：靠 `storeResultBean("名字", 数据, REQUEST)` 和 JSP 里 `<bean:write name="名字">` **同名**

另外还有一个**页面拼装系统 tiles**（第 3 章讲），它是"页面 → 页面"的映射，跟数据无关。

---

## 2. 完整例子：応札結果詳細画面（仓库内全链路闭环）

这个例子小而完整，从按钮点下去到数据上屏，7 步全部能在仓库里看到。
**看懂这一个，其他页面都是同样的套路。**

### 第 1 步：JS 拼出 URL（① 的入口）

文件：`WebContent/jsp/buyer/js/buyer/common/osatsushosai.js:31-45`

```js
function openIndOsatsuSyosai(context, nyusatsuNo, hatsuCd, juchuCd, seriesNo) {
    ...
    call_url = 'app_indosatsushosai.do?';                       // ← ① 就是这个 URL
    call_url = call_url + 'nyusatsuNo=' + nyusatsuNo + '&seriesNo=' + seriesNo
                       + '&juchuCd=' + juchuCd + '&hatsuCd=' + hatsuCd
                       + '&seriesFlag=' + seriesFlag;
    syosaiWindow = window.open(call_url, ...);                  // 弹窗打开
}
```

> **怎么找入口**：JSP 里找 `onclick=...`，或全局 `rg -n "xxx.do" WebContent/jsp WebContent/jsp/**/js`。

### 第 2 步：URL → struts Action（查表①）

文件：`WebContent/WEB-INF/struts-config.xml:1381`

```xml
<!-- 応札結果詳細  -->
<action path="/app_indosatsushosai"                     ← URL 去掉 .do 就是这个 path
    type="jp.co.toshiba_sol.wakaba.web.BaseAction"      ← 框架统一入口类
    name="BaseActionForm" scope="request" validate="false"
    input="/jsp/buyer/sheet/kanni/indent/common/viewer_indreply_dtl.jsp">
    <forward name="OsatsuShosai"                        ← ★ 这个名字是 Service 决定的（第 6 步）
        path="/jsp/buyer/sheet/kanni/indent/common/viewer_indreply_dtl.jsp" />  ← 最终渲染的 JSP
</action>
```

**关键点**：一个 `<action>` 里可以有多个 `<forward>`，**到底走哪个，由 Service 返回的 forward 名决定**（不是这里写死的）。

> 验证命令：
> ```bash
> rg -n 'path="/app_indosatsushosai"' ebid/WebContent/WEB-INF/struts-config.xml
> ```

### 第 3 步：Action → Service 名（查表②）

文件：`WebContent/WEB-INF/xml/action-service.xml:1374`

```xml
<!-- 応札結果詳細  -->
<action name="/app_indosatsushosai">              ← 和 struts 的 path 完全一样（去掉 .do）
    <servicename value="OsatsuShosaiService" />   ← ★ 要执行的 Service 名
</action>
```

**这个文件就是"Action → Service"的总映射表**，全项目所有页面的 Service 都在这里登记。
`name` 和 struts 的 `path` 是**同一个字符串**，这就是两表关联的钥匙。

另外有的条目还会带"翻译器"（在 Service 前后执行，用来做权限/邮件/DMS 检查）：

```xml
<action name="/wf_stdind_approval">
    <servicename value="ManagedService" />
    <list name="translatorclass">
        <item name="jp.co.toshiba_sol.esup.security.translator.SecurityTrapTranslator" />
        <item name="jp.co.toshiba_sol.esup.common.mail.translator.ShoninMailTranslator" />
        ...
    </list>
    <service-param><property key="form" RUG_MANAGED_NAME="exec_buyer_approval" /></service-param>
</action>
```

> **谁在读这两张表？** 框架类 `jp.co.toshiba_sol.wakaba.web.BaseAction`（在 `WEB-INF/lib/rug_web.jar` 里）。
> 我把它反编译看常量，能直接看到它调用的方法名，串起整个流程：
> ```
> getAssociateServiceName   ← 用 action path 去 action-service.xml 查 servicename
> action-service.action-controller / "servicename"   ← 配置文件名和标签名
> BaseServiceLocator.lookup ← 拿 servicename 找 Service 对象
> executeService            ← 调 Service.execute()
> getForward / findForward / "Forwarding name : "    ← 拿 Service 返回的 forward 名，查 struts 的 <forward>
> ```
> 所以 **BaseAction 就是②③④⑤⑥的执行者**。

### 第 4 步：Service 名 → Java 类（约定：同名）

`action-service.xml` 只给了一个名字 `OsatsuShosaiService`，怎么变成对象？

```xml
<!-- WebContent/WEB-INF/xml/service-locator.xml 最后一行：兜底规则 -->
<service name=".*" type="manager" reference="Remote_Ebid" />
```

流程：`BaseServiceLocator.lookup("OsatsuShosaiService")`
→ 匹配 `.*` → 走 RMI 到 `Remote_Ebid` 服务 → **按"类简单名 == Service 名"的约定实例化类**：

```
OsatsuShosaiService  →  jp.co.toshiba_sol.esup.bid.buyer.service.common.shosai.OsatsuShosaiService
```

> **验证约定**（随便挑一个 servicename 都能对上）：
> ```bash
> rg -n '<servicename value="OsatsuShosaiService"' ebid/WebContent/WEB-INF/xml/action-service.xml
> rg -l "class OsatsuShosaiService" ebid/src
> ```

### 第 5 步：Service 干活（查数据库）

文件：`src/jp/co/toshiba_sol/esup/buyer/service/common/shosai/OsatsuShosaiService.java`

```java
public CommonDataSet execute(String acname, Map form, Map other) {
    CommonDAO dao = CommonDAO.getInstance();
    dao.open(Constants.DENSI_DB);                     // 打开"电子入札"数据库

    BidOsatsuShosaiEntity ousatsEntity = new BidOsatsuShosaiEntity(dao);   // 查表的类
    shosaiInfoMap = ousatsEntity.getOusatsuKekkaShoSai(form);              // ★ 真正查 DB

    shosaiInfoMap.put("isKaigai", isKaigai);           // 顺手加工几个字段
    dao.close();

    CommonDataSet dset = new CommonDataSet();
    dset.storeResultBean("ousatsuKekkaShosai", shosaiInfoMap, CommonDataSet.REQUEST);  // ★④ 放进 request
    dset.setForwardString("OsatsuShosai");                                        // ★⑤ 返回 forward 名
    return dset;
}
```

Entity 里才是真正碰 SQL 的地方：`src/.../entity/BidOsatsuShosaiEntity.java:111`

```java
String sltSql = SqlSet.getBuyerSql(SqlConst.OSATSU_SHOSAI_SELECT01);  // 拿 SQL 文本
Object[] sltPara = new Object[] { locale, seriesNo, seriesFlag, nyusatsuNo, hatsuCd, juchuCd };
List list = (List) dao.select(sltSql, sltPara);                       // 执行查询
```

**SQL 文本在哪？** `SqlSet.getBuyerSql(key)` → 解析 classpath 上的 `/buyer-sql-statements.xml`
（`SqlXMLParser.java:52`）。⚠️ 这个文件**不在本仓库**，是部署时提供的。
仓库里能直接看到 SQL 文本的只有 common 组：`batch/common/config/common-sql-statements.xml`
（例如 `:349 job_select06 … FROM BID_JOB`）。

**查表分层口诀**：
```
Service（业务、组装、放 request）
  └─ Entity（拼 SQL、映射结果，一个表/一组表一个 Entity）
       └─ SqlSet/SqlConst（SQL 文本的 key，小写下划线）
            └─ buyer-sql-statements.xml（key → SQL 原文，部署环境）
                 └─ CommonDAO.select(sql, params) → DB
```

### 第 6 步：forward 名 → JSP（回到表①）

Service 返回 `setForwardString("OsatsuShosai")`，
`BaseAction` 拿这个名字去 struts 的 `<action>` 里 `findForward("OsatsuShosai")`，
命中第 2 步那段配置：

```xml
<forward name="OsatsuShosai" path="/jsp/buyer/sheet/kanni/indent/common/viewer_indreply_dtl.jsp" />
```

→ 渲染 `viewer_indreply_dtl.jsp`。

### 第 7 步：JSP 取数据（④ 的另一半，必须同名）

文件：`WebContent/jsp/buyer/sheet/kanni/indent/common/viewer_indreply_dtl.jsp:44`

```jsp
<logic:notEmpty name="ousatsuKekkaShosai" >                       ← 名字 1：request 里的 key
  <bean:write name="ousatsuKekkaShosai" property="JUCHU_NAME" ignore="true"/>   ← 取出字段 JUCHU_NAME
</logic:notEmpty>
```

**对账（三处必须对上，链路才算闭环）：**

| 对账项 | 位置 1 | 位置 2 | 是否一致 |
|---|---|---|---|
| 数据 key | `OsatsuShosaiService:153` `storeResultBean("ousatsuKekkaShosai",…)` | `viewer_indreply_dtl.jsp:44` `<bean:write name="ousatsuKekkaShosai">` | ✅ |
| forward 名 | `OsatsuShosaiService:159` `setForwardString("OsatsuShosai")` | `struts-config.xml:1385` `<forward name="OsatsuShosai">` | ✅ |
| Service 名 | `action-service.xml:1375` `servicename=OsatsuShosaiService` | 类 `OsatsuShosaiService.java` | ✅ |

> **三处对上 = 完整闭环。以后你查任何页面，就是做这三处对账。**

### 时序图（把这个例子再串一遍）

```
浏览器                     struts-config.xml      action-service.xml      Service/Entity/DB         JSP
  │ app_indosatsushosai.do │                          │                      │                       │
  ├───────────────────────►│                          │                      │                       │
  │                        │ path 匹配 → BaseAction   │                      │                       │
  │                        ├─────────────────────────►│                      │                       │
  │                        │                          │ name→OsatsuShosai…   │                       │
  │                        │                          ├─────────────────────►│                       │
  │                        │                          │                      │ Entity→SQL→DB 查数据  │
  │                        │                          │                      │ storeResultBean(key)  │
  │                        │                          │                      │ setForwardString(F)   │
  │                        │◄─────────────────────────┴──────────────────────┤                       │
  │                        │ findForward(F) → JSP 路径                                                │
  │◄───────────────────────┴─────────────────────────────────────────────────────────────────────────┤
  │                                                                                                 │
  │                     请求结束时框架把 CommonDataSet 里 REQUEST 的东西 setAttribute 到 request      │
  │                     JSP 执行 <bean:write name="key"> 取出                                        │
```

---

## 3. 第二个例子：`content_stdind_dsnapp.jsp` 为什么"找不到 Action"

你最初问的这个 JSP，它**没有自己的 action**，因为它是被别的页面**包含进去的片段（inner1）**。
这类页面靠的是**另一套映射：tiles（页面 → 页面）**。这里重点讲"怎么拼"。

### 3.1 tiles 的三层拼装

以 `content_stdind_dsnapp.jsp` 为例，`rg -n "content_stdind_dsnapp" ebid/WebContent/jsp/layout/` 得到：

```xml
<!-- WebContent/jsp/layout/tiles-buyer.xml:9  最底层的"画框" -->
<definition name="sheet.base" path="/jsp/buyer/buyer_inners.jsp">
    <put name="inner_error" value="/jsp/common/error.jsp" />
</definition>

<!-- tiles-buyer.xml:709  中间层：把 inner1 指到我们的 JSP -->
<definition name="stdind_dsnapp.base" extends="sheet.base">     ← extends = 继承
    <put name="inner1" value="/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp" />
</definition>

<!-- tiles-buyer.xml:721  最外层：给它一个正式名字 -->
<definition name="buyer_stdind_dsnapp" extends="stdind_dsnapp.base">
    <put name="id" value="buyer_stdind_dsnapp" />
</definition>
```

**拼装链条**：

```
buyer_stdind_dsnapp  ──extends──►  stdind_dsnapp.base  ──extends──►  sheet.base
   (只加 id)                          (inner1 = 我们的JSP)             (path = buyer_inners.jsp，画框)
```

最后由 `WebContent/jsp/buyer/buyer_inners.jsp:41-43` 把片段真的输出到 HTML：

```jsp
<div id="inner1">
  <tiles:insert attribute='inner1' ignore='true' flush='true' />   ← 这里才输出 content_stdind_dsnapp.jsp
</div>
```

> 所以：**JSP 是"被放进画框里的画"**。要找它被谁用，不是找 action，而是**拿文件名去 `jsp/layout/*.xml` 反查 definition**。

### 3.2 那 definition 又是谁选出来的？—— key 拼接

`content_stdind_dsnapp.jsp` 被两个 definition 引用，对应两种画面：

| 画面 | definition | 用哪张映射表 |
|---|---|---|
| 承认/申请操作画面 | `buyer_stdind_dsnapp` | `tiles-defs.xml` 的 `sheet_0004` |
| 进度"内容表示"弹窗（只读） | `buyer_stdind_expapp_dsp` | `tiles-defs.xml` 的 `process_0004` |

**映射表长这样**（`WebContent/jsp/layout/tiles-defs.xml:137`）：

```xml
<putList name="sheet_0004">                        ← key = "sheet_" + SHEET_ID
    <item value="BRI_EVENT01" link="buyer_stdind_motion" />
    <item value="BRI_EVENT02" link="buyer_stdind_dsnapp" />   ← 设计承认 → 我们的 JSP
    <item value="BRI_EVENT03" link="buyer_stdind_expapp" />
    ...
</putList>
```

**"拼"就拼在 key 上**（`WebContent/jsp/layout/base_layout.jsp:118`）：

```java
List<SimpleMenuItem> sheetList = (List) pageContext.getAttribute( "sheet_" + sheetId );
//                                          ^^^^^^^^^^^^ 字符串拼接："sheet_" + "0004" = "sheet_0004"
...
forwardSheetMap.put(sheetId, sheetMap);   // 再套一层：FORWARD_SHEET_MAP["0004"]["BRI_EVENT02"] = "buyer_stdind_dsnapp"
pageContext.setAttribute("FORWARD_SHEET_MAP", forwardSheetMap, APPLICATION_SCOPE);
```

消费方 `WebContent/jsp/workflow/contents/data_forward.jsp:27-50`：

```java
Map draftInfMap  = (Map) request.getAttribute("wfDraftInfMap");   // 本次要显示哪张单据
String sheetId   = (String) draftInfMap.get("SHEET_ID");          // 例："0004"
String oriAppEventId = (String) draftInfMap.get("ORIGINAL_APP_EVENT_ID");  // 例："BRI_EVENT02"

Map useMap   = (Map) pageContext.getAttribute("FORWARD_SHEET_MAP", APPLICATION_SCOPE);
String sheetType = (String) useMap.get(sheetId).get(oriAppEventId);   // → "buyer_stdind_dsnapp"

<tiles:insert definition="<%=sheetType%>" />    ← 把拼出来的 definition 名插入
```

进度弹窗那边（`viewer_processdsp.jsp`）**逻辑一模一样**，只是前缀不同：

```java
pageContext.getAttribute("process_" + sheetId)   // "process_" + "0004" = "process_0004"
// tiles-defs.xml:1649 → BRI_EVENT01/02/03 → buyer_stdind_expapp_dsp
```

> **记忆点**：这个项目里 key 拼接就两种写法，看到 `"xxx_" + 变量` 就要去 `tiles-defs.xml` 找同名的 `putList name="xxx_..."`。

### 3.3 另一种拼法：Struts 通配符 `{1}`

`struts-config.xml:4497`：

```xml
<action path="/buyer_*" extends="/base">
    <forward name="success"            path="buyer_{1}" />   ← {1} = path 里 * 匹配到的部分
    <forward name="SeriesNyusatsuIraiJoho" path="buyer_{1}" />
    ...
</action>
```

**举例**：如果代码执行 `mapping.findForward("success")`，而当前 action 是 `/buyer_stdind_dsnapp`，
则 `{1}` = `stdind_dsnapp`（`/buyer_` 后面的部分），于是 forward 到 tiles 定义 **`buyer_stdind_dsnapp`** ——
正好接上 3.1 节那个 definition。

同族的还有 `struts-config.xml:4508` 起：
```xml
<action path="/to_wf_*">  <forward name="success" path="id_wf_{1}" />  </action>
<action path="/to_sys_*"> <forward name="success" path="id_sys_{1}" /> </action>
<action path="/to_buy_*"> <forward name="success" path="id_buy_{1}" /> </action>
```

> **这就是"拼出来的"**：`/to_wf_draft` → `id_wf_draft` → `tiles-defs.xml` 里 `<definition name="id_wf_draft">`。

### 3.4 这个 JSP 的数据是谁给的

因为它是片段，数据由**上一层 Action 的 Service** 填。本 JSP 用到的 request 属性：

| JSP 里的写法 | 谁写进去的 |
|---|---|
| `<bean:write name="NYUSATSUJOHO_UP" property="NYUSATSU_NO">`（:142） | `StdIndNyusatsuIraiJohoService.java:319` 或 `RirekiNyusatsuIraiJohoService.java:441` |
| `<logic:iterate name="kiboJuchuInfo">`（:183） | 同上 `:324` / `:210` |
| `request.getAttribute("nyusatu")`（:482） | 同上 `:257` / `:427` |
| `COMMENT_MAP`（:84） | `RirekiNyusatsuIraiJohoService.java:446` |
| `HaveBuyerDoc`（:515） | `DMSTranslatorHelper.java:1372`（Action 前后的 translator） |
| `wfDraftInfMap`（:458） | WF 框架 `SheetDisplayService`（`esup_wf2.jar`） |

主数据的取数链：

```
StdIndNyusatsuIraiJohoService.execute()
  ├─ BidJobEntity.getJobInfo(form)              PROCESS_ID → BID_JOB（拿 NYUSATSU_NO 等）
  ├─ BidIraiEntity.getDispNyusatsuIraiJoho()    ★主数据
  │     └─ SqlSet.getBuyerSql("irai_select01")  → BID_IRAI（見積依頼テーブル）
  ├─ BidRequestEntity / BidJuchuEntity          希望受注者 / 受注者
  ├─ MeisaiTblEntity.getStatus()                硬编码 SQL → BID_MEISAI_TBL（見積内訳状态）
  └─ dset.storeResultBean(Constants.NYUSATSUJOHO_UP, map, REQUEST)
```

⚠️ **唯一断链**：`action-service.xml` 里 `/wf_draft`、`/wf_process_display` 走的是
`ManagedService` + `RUG_MANAGED_NAME="exec_wf_draft"`，它读取的 **`managed-service.xml` 不在本仓库**
（我解压了 `WEB-INF/lib` 全部 jar 逐个 grep 过）。所以"这次请求具体调的是
`StdInd…` 还是 `Rireki…`"只能运行期确认——两个 Service 一进方法就打日志：

```
● StdIndNyusatsuIraiJohoService.execute start
● RirekiNyusatsuIraiJohoService start
Managed: execute name=...
```

---

## 4. 通用 SOP：拿到任意一个 JSP，5 条命令查清它的数据来源

```bash
cd E:/agent/pi/day1109/ebid

# ① 这个 JSP 是片段还是独立页面？被哪些 tiles 定义引用？
rg -n "你的文件名.jsp" WebContent/jsp/layout/
#   有结果 → 是片段，记下 definition 名（如 buyer_stdind_dsnapp）

# ② 找入口 Action（两选一）
#   (a) 通配 forward：forward 名里含 definition 名
rg -n 'buyer_\{1\}|path="buyer_stdind_dsnapp"' WebContent/WEB-INF/struts-config.xml
#   (b) key 拼接：去 tiles-defs.xml 找谁 link 到这个 definition
rg -n 'link="buyer_stdind_dsnapp"' WebContent/jsp/layout/tiles-defs.xml
#        → 得到 SHEET_ID(0004) + 事件(BRI_EVENT02)，再看 base_layout.jsp / data_forward.jsp 怎么拼

# ③ Action → Service 名
rg -n 'name="/app_xxx"' WebContent/WEB-INF/xml/action-service.xml

# ④ Service 名 → 类 → 往 request 放了什么
rg -l "class XxxService" src
rg -n "storeResultBean|setForwardString" src/.../XxxService.java

# ⑤ 对账：Service 的 key 是否 == JSP 的 <bean:write name=...>
rg -n 'bean:write name="key"' WebContent/jsp/...
```

**对账成功 = 找到数据来源**；④里再往下就是 `Entity → SqlConst → buyer-sql-statements.xml → 表`。

### 反过来也一样（从 Service 找页面）

```bash
rg -n 'storeResultBean\("NYUSATSUJOHO_UP"' -g "*.java" src     # 谁生产这个数据
rg -n 'setForwardString\("OsatsuShosai"\)' -g "*.java" src     # 它把画面送到哪
```

---

## 5. 常见疑问 FAQ

**Q1：为什么有些 JSP 找不到对应的 action？**
因为它不是"一个请求一个页面"，而是被 tiles 包含的片段（inner1/inner2）。
它跟上层页面共用同一个 Action 和 Service。查法见第 3 章。

**Q2：`action-service.xml` 和 `struts-config.xml` 什么区别？**
- `struts-config.xml`：**URL → 页面**（struts 标准配置，管路径、表单、forward）
- `action-service.xml`：**URL → Service**（自研框架的配置，管业务逻辑）
  两表靠 **完全相同的 path/name 字符串** 关联，由 `BaseAction`（rug_web.jar）串起来。

**Q3：`storeResultBean` 的数据怎么到 request 的？**
`CommonDataSet` 是个"暂存箱"，`execute()` 返回后由框架统一
`request.setAttribute(key, value)`（`CommonDataSet.REQUEST` 表示放 request 作用域；
还有 SESSION / APPLICATION 等）。所以 JSP 里直接 `<bean:write name="key">` 就能拿到。

**Q4：`form` 是什么？**
`execute(String acname, Map form, Map other)` 里的 `form` 就是 **HTTP 请求参数 + 登录用户信息**合成的 Map，
Entity 用 `MapUtils.getString(form, "nyusatsuNo")` 取值当查询条件。
所以"页面传了什么参数"要在 JS/表单里找，不在 Service 里。

**Q5：SQL 文本为什么找不到？**
`SqlSet.getBuyerSql("key")` 读的是 classpath 上的 `buyer-sql-statements.xml`，
**不在仓库**（部署资源）。仓库里能看 SQL 的只有：
- `batch/common/config/common-sql-statements.xml`（common 组）
- Entity 里**硬编码**的 SQL（如 `MeisaiTblEntity` 的 `SELECT * FROM BID_MEISAI_TBL ...`）

**Q6：`ServiceLocator.lookup("XxxService")` 到底怎么变成对象？**
`service-locator.xml` 里一条兜底规则 `<service name=".*" reference="Remote_Ebid"/>`
→ 所有未显式登记的 Service 都发给 RMI 的 `Remote_Ebid` → 由它按**类简单名同名约定**实例化。
（`service-locator.xml` 里显式登记的只有 `ManagedService`、`DmsXxxService` 这类框架/远程服务。）

---

## 6. 一页速记卡

```
【页面】 struts-config.xml  path="/xxx" ──forward name──► tiles definition 或 .jsp
              │ 同一个 path/name
【业务】 action-service.xml  name="/xxx" ──servicename──► XxxService（类同名）
              │
【取数】 XxxService.execute(form) → XxxEntity → SqlSet(SqlConst key) → buyer-sql-statements.xml → DB
              │
【回传】 dset.storeResultBean("key", data, REQUEST)     ←→ JSP: <bean:write name="key">
         dset.setForwardString("F")                    ←→ struts: <forward name="F" path="..."/>
              │
【拼接】 "{前缀}" + sheetId   → tiles-defs.xml 的 putList name="{前缀}{sheetId}"
         "buyer_{1}" / "id_wf_{1}" → struts 通配符
【片段】 JSP 片段靠 tiles extends 链：definition → .base → sheet.base → buyer_inners.jsp → inner1
```
