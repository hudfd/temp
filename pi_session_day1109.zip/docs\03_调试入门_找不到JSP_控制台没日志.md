# 调试入门：找不到 JSP、Eclipse 控制台一片空白，怎么办

> 仓库：`E:/agent/pi/day1109/ebid`（Eclipse 工程名 `ebid`，Dynamic Web Project + Tomcat 7 (Java 8)）
> 本文只解决两件事：**① 找到你点的那个按钮对应的 JSP；② 让日志/输出打出来。**
> 每条都带真实路径和命令，可以照着做。

---

## 0. 先说结论：你控制台是空的，不是你的错，是配置就这样

### 原因 1：这个项目的 log4j **根本没配控制台输出**

`src/log4j.xml`（全文就两个 appender）：

```xml
<appender name="FILE" class="org.apache.log4j.DailyRollingFileAppender">
    <param name="File" value="${log.home}/ebid-web.log" />     ← 只写文件
</appender>
<appender name="AccessLog" class="org.apache.log4j.DailyRollingFileAppender">
    <param name="File" value="${log.home}/ebid-access.log" />   ← 只写文件
</appender>
...
<category name="jp.co.toshiba_sol" additivity="false">
    <level value="DEBUG" />
    <appender-ref ref="FILE" />        ← 业务日志全进文件
</category>
<root>
    <level value="INFO" />
    <appender-ref ref="FILE" />
</root>
```

**没有 `ConsoleAppender`**，所以不管代码跑得多热闹，Eclipse 控制台都不会有 log4j 的输出。
（`WebContent/WEB-INF/lib/ebid_common.jar` 里还有一份**一模一样的 log4j.xml**，也是只写文件。）
唯一有 ConsoleAppender 的是 `batch/mitumoriUtiwakeAuthDaily/bin/log4j.xml`，那是批处理用的，跟 web 无关。

### 原因 2：日志文件路径取决于 JVM 参数 `-Dlog.home`

`${log.home}` 是**系统属性**，必须在 Tomcat 启动参数里给，例如：
```
-Dlog.home=D:/logs/ebid
```
如果没人设，日志会写到一个字面名叫 `${log.home}` 的目录，或者干脆初始化失败。
→ 所以第一步是**找到这个 log.home 到底指向哪**（见 §3.1）。

### 原因 3：Eclipse 控制台只显示"从 Eclipse 启动的那个进程"的输出

- JSP 里的 `System.out.println` → 进 **Tomcat 进程的 stdout** → 只有你用 Eclipse Servers 视图启动的 Tomcat 才会显示
- log4j 的 `LOGGER.info(...)` → 进 **文件**（原因 1）
- 如果 Tomcat 是**别人启动的 / 脚本启动的 / 远程服务器**，Eclipse 控制台**永远是空的**

> 本项目 JSP 里确实有 `System.out.println`（23 个 JSP），例如
> `WebContent/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp:31`
> `<%System.out.println("content_stdind_dsnapp.jsp"); %>`
> —— **你要是连这一行都没看到，说明这个 JSP 压根没被执行，或者你连的不是 Eclipse 里跑的那个 Tomcat。**

---

## 1. 开工前，5 分钟做 3 个确认

### 确认 ①：你浏览器访问的是哪个 context

本工程的 context-root 写死在 `.settings/org.eclipse.wst.common.component`：

```xml
<wb-module deploy-name="ebid">
    <wb-resource deploy-path="/" source-path="/WebContent"/>
    <wb-resource deploy-path="/WEB-INF/classes" source-path="/src"/>
    <property name="java-output-path" value="/ebid/src"/>     ← 注意：编译输出目录就是 src 本身
    <property name="context-root" value="/pcmv2std/develop/ebid"/>   ← ★ URL 前缀
</wb-module>
```

所以正常 URL 长这样：
```
http://localhost:8080/pcmv2std/develop/ebid/xxx.do
```
`WebContent/WEB-INF/xml/framework-property.xml:17/22` 里 `wf_path` / `app_path` 也是同一个前缀。

👉 **看一眼地址栏**：如果 host:port 不是你在 Eclipse 里启动的那个，控制台当然什么都没有。

### 确认 ②：Tomcat 是不是 Eclipse 启动的

1. `Window → Show View → Servers`，看有没有 `Tomcat v7.0 Server at localhost [Started]`
2. 双击这个 Server：
   - **Server Locations**：`Use workspace metadata`（说明用的是 Eclipse 部署的这份代码）
     如果选了 `Use Tomcat installation` + 指向别处，那你改的代码**根本没跑**
   - **Modules**：确认部署的是 `ebid` 这个项目
3. 右键 Server → `Restart`（改了 Java 必须重启；改 JSP 一般会热加载）

### 确认 ③：看的是不是正确的 Console

Console 视图**右上角有个下拉小箭头**，里面可能有多个控制台（Tomcat、启动任务、Ant…），
选带 `Tomcat` 字样的那个；旁边还有"清除"按钮。很多时候只是看错了 tab。

---

## 2. 第一步：怎么找到"我点的这个按钮"对应的 JSP（不需要任何日志）

### 办法 A（最快）：查看网页源代码，看 JSP 头部的 `画面名：`

**本项目 735 个 JSP 的头部注释都写了自己的路径**，例如：

```
WebContent/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp:3
   機能：ワークフロー 入札依頼インデント品 設計承認と输出管理承認
   画面名：/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp
```

操作：
1. 浏览器里对着出问题的页面 → 右键 → **查看网页源代码**（View Source）
2. `Ctrl+F` 搜 `画面名` → 直接得到 JSP 路径
3. Eclipse 里 `Ctrl+Shift+R`（Open Resource）输入文件名打开

> ⚠️ 局限：你看到的是**最外层那个 JSP**（框架画框），内容片段要再往下追一层——见办法 B 的例子。

### 办法 B（最可靠）：F12 抓 URL → 按映射表一路查下去

1. 浏览器 `F12` → **Network（网络）** 标签 → 勾选 `Preserve log`
2. 点你关心的按钮 → 看发出的请求 URL，通常是 `xxx.do?参数...`
3. 拿 `xxx.do` 去查两张表：

```bash
cd E:/agent/pi/day1109/ebid

# URL → 页面（struts）
rg -n 'path="/xxx"' WebContent/WEB-INF/struts-config.xml
# URL → 业务（自研框架）
rg -n 'name="/xxx"' WebContent/WEB-INF/xml/action-service.xml
```

4. 看 `<forward name="..." path="...">`：
   - `path` 是 `.jsp` 结尾 → **那就是页面**，完事
   - `path` 是 `flow_processdsp`、`buyer_stdind_dsnapp`、`id_wf_draft` 这种**不是文件名** → 它是 tiles 定义名，继续查：

```bash
rg -n 'definition name="flow_processdsp"' -A 3 WebContent/jsp/layout/tiles-defs.xml
#   path="/jsp/workflow/contents/viewer_processdsp.jsp"   ← 先拿到这个 JSP

# 如果 forward 的是 buyer_xxx 这种，还要看 inner 片段：
rg -n 'definition name="buyer_stdind_expapp_dsp"' -A 3 WebContent/jsp/layout/*.xml
rg -n 'content_stdind_dsnapp' WebContent/jsp/layout/*.xml
#   <put name="inner1" value="/jsp/.../content_stdind_dsnapp.jsp" />   ← 真正的内容 JSP
```

### 🌰 完整走一遍（你原来的问题：点"进度→内容表示"）

| # | 动作 | 结果 |
|---|---|---|
| 1 | F12 抓包 | 请求 `wf_process_display.do`（来源 `WebContent/jsp/workflow/js/flowcommon.js:519`、`flow.js:1327`：`COMMON_WF_INFO.action='wf_process_display.do'`） |
| 2 | 查 struts | `struts-config.xml:1502` → `<forward name="success" path="flow_processdsp"/>` |
| 3 | 查 tiles | `tiles-defs.xml:1574` → `<definition name="flow_processdsp" path="/jsp/workflow/contents/viewer_processdsp.jsp">` |
| 4 | 打开该 JSP 看源码 | 里面有 `<tiles:insert definition="<%=sheetType%>"/>`，`sheetType` 是**运行时算出来的** |
| 5 | 算 sheetType | `viewer_processdsp.jsp` 用 `"process_" + sheetId` 拼 key → `tiles-defs.xml:1649 putList name="process_0004"` → `BRI_EVENT02 → buyer_stdind_expapp_dsp` |
| 6 | 查这个 definition | `tiles-buyer.xml:344` `<definition name="stdind_expapp_dsp.base">` → `<put name="inner1" value=".../content_stdind_dsnapp.jsp"/>` |
| 7 | ✅ 找到了 | `WebContent/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp` |
| 8 | 顺手看 Service | `action-service.xml:1520` → `servicename=ManagedService` + `RUG_MANAGED_NAME="exec_wf_processdsp"` |

> 注意第 5 步：这种"运行时才拼出来"的页面，**静态搜索 forward 是查不到的**，
> 必须理解 `"前缀" + 变量` 的拼接规则（见 `base_layout.jsp:118` 的 `"sheet_" + sheetId`）。

### 办法 C：从按钮的 onclick 反查 JS

1. 按钮右键 → 检查（Inspect）→ 看 `onclick="xxx(...)"`
2. ```bash
   rg -n "xxx" WebContent/jsp --glob "*.js" --glob "*.jsp"
   # 常见结果：COMMON_WF_INFO.action='wf_process_display.do'  ← 又回到办法 B
   ```

### 办法 D：Eclipse 里直接搜

- `Ctrl+Shift+R`：输入 `*dsnapp*.jsp`（支持通配）
- `Ctrl+H`：File Search → 搜 `画面名：/jsp/.../xxx.jsp`，或搜 `.do` 字符串
- 打开 JSP 后 `Ctrl+F` 搜 `画面名`，头部注释会告诉你它自己是谁

---

## 3. 第二步：让日志/输出出来（三选一，推荐顺序 3.1 → 3.3 → 3.2）

### 3.1 【最省事】直接看日志文件（先找 log.home）

日志**本来就有，只是不进控制台**。找 `log.home` 指向哪：

```bash
# Eclipse 里：双击 Servers 中的 Tomcat → 左下 "Open launch configuration" → Arguments → VM arguments
#   里面找 -Dlog.home=...
# 或者搜启动脚本：
rg -n "log.home" /path/to/tomcat/bin /path/to/tomcat/conf
rg -rn "log.home" E:/agent/pi/day1109     # 仓库里（可能没有，说明在服务器启动脚本里）
```

拿到目录后看这两个文件：

| 文件 | 内容 |
|---|---|
| `${log.home}/ebid-web.log` | **业务日志，级别 DEBUG**（category `jp.co.toshiba_sol`），Service/Entity 的 `LOGGER.info/debug` 全在这 |
| `${log.home}/ebid-access.log` | 访问日志（AccessLogFilter） |

打开后直接搜关键字，立刻能看到链路：

```
● StdIndNyusatsuIraiJohoService.execute start
● BidIraiEntity.getDispNyusatsuIraiJoho invoke
● OsatsuShosaiService.execute start
Managed: execute name=...
```

> **如果你在 ebid-web.log 里能搜到这些，说明代码在跑，只是控制台不显示**——那就不用折腾控制台了。

### 3.2 【要效果】给 log4j 加 ConsoleAppender

改 `src/log4j.xml`（⚠️ `ebid_common.jar` 里也有一份同名的，classpath 上 `src` 在 jar 之前，
`.classpath` 第一行就是 `<classpathentry kind="src" path="src"/>`，所以改 src 这份一般会生效；
若不生效，说明 jar 里的那份先加载了 → 需要改 jar 或删掉 jar 里那份）：

```xml
<appender name="CONSOLE" class="org.apache.log4j.ConsoleAppender">
    <layout class="org.apache.log4j.PatternLayout">
        <param name="ConversionPattern" value="%d{HH:mm:ss} %-5p [%c{1}] %m%n" />
    </layout>
</appender>

<!-- 让业务日志同时进控制台 -->
<category name="jp.co.toshiba_sol" additivity="false">
    <level value="DEBUG" />
    <appender-ref ref="FILE" />
    <appender-ref ref="CONSOLE" />     ← 加这行
</category>

<root>
    <level value="DEBUG" />
    <appender-ref ref="CONSOLE" />     ← 加这行
</root>
```

改完：**Eclipse 里对工程右键 `Project → Clean...` → 重启 Tomcat**
（因为本工程 `java-output-path=/ebid/src`，资源会被复制，Clean 保证生效）。

#### ⚠️ 3.2.1 如果加了 ConsoleAppender 还是不生效，按这个顺序查

全项目只有 **两份 log4j.xml**（已全量确认，其它 jar 里都没有）：

| # | 位置 | 谁会用到 |
|---|---|---|
| 1 | `src/log4j.xml` | 编译输出目录就是 `src`（`.classpath` `output path="src"`），部署时拷到 `WEB-INF/classes/log4j.xml` |
| 2 | `WebContent/WEB-INF/lib/ebid_common.jar!/log4j.xml` | jar 内同名资源 |

Tomcat 的 `WebappClassLoader` 默认 **`WEB-INF/classes` 优先于 `WEB-INF/lib/*.jar`**，
所以理论上改 `src/log4j.xml` 就够了。不生效就是下面某一条：

**① 改动没到运行时（最常见）**
到**实际部署目录**里打开那份文件，看有没有你加的 `CONSOLE`：
```
Eclipse: 双击 Servers 里的 Tomcat → Server Locations → Deploy path
一般在 workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp*/wtpwebapps/ebid/WEB-INF/classes/log4j.xml
```
没有 → `Project → Clean...` → 右键 Server → `Restart`。

**② 不知道 log4j 到底读了哪份 → 用它自带的诊断开关**
在 Tomcat 的 VM arguments 里加：
```
-Dlog4j.debug=true
```
重启后控制台会打印加载过程，例如：
```
log4j: Trying to find [log4j.xml].
log4j: Using URL [jar:file:/.../ebid_common.jar!/log4j.xml]   ← 看到这句就知道该改哪份
```
如果显示的是 jar 路径 → 你改的 `src/log4j.xml` 没生效（回①）。

**③ 配置根本没加载成功（解析失败 / 打不开文件）**
`log4j.xml` 顶部有 `<!DOCTYPE log4j:configuration SYSTEM "log4j.dtd">`，依赖 classpath 上的 `log4j.dtd`
（`src/log4j.dtd` 和 `ebid_common.jar!/log4j.dtd` 都有）。如果你手改后 XML 格式错了、
或 `log.home` 没设导致 FileAppender 打不开文件，log4j 会往 stderr 打警告然后**什么日志都不记**。
→ 看控制台有没有 `log4j:WARN ...` / `ERROR in receiver` 之类。

**④ 干脆绕开它：用外部配置文件（最可靠）**
自己写一份 `D:/debug/log4j-console.xml`：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE log4j:configuration SYSTEM "log4j.dtd">
<log4j:configuration xmlns:log4j="http://jakarta.apache.org/log4j/">
  <appender name="CONSOLE" class="org.apache.log4j.ConsoleAppender">
    <layout class="org.apache.log4j.PatternLayout">
      <param name="ConversionPattern" value="%d{HH:mm:ss} %-5p [%c{1}] %m%n"/>
    </layout>
  </appender>
  <root><level value="DEBUG"/><appender-ref ref="CONSOLE"/></root>
</log4j:configuration>
```
VM arguments：
```
-Dlog4j.configuration=file:/D:/debug/log4j-console.xml
-Dlog.home=D:/logs/ebid
```
`-Dlog4j.configuration` **优先级最高**，直接指定文件，不再管 classpath 里那两份。

**⑤ log.home 没设时，日志文件去哪了**
log4j 会把 `${log.home}` 当字面量用 → 去 **Tomcat 启动目录（通常 `bin/`）**找一个名字就叫 `${log.home}` 的文件夹，
或全盘搜 `ebid-web.log`。找到后直接看，那里面本来就是 DEBUG，比控制台还全。

**⑥ 以上都对还是没输出** → 回 §1：你连的可能不是 Eclipse 里跑的那个 Tomcat。

### 3.3 【最土但最灵】System.out.println 打点

本项目本来就是这么干的（23 个 JSP 里有），可以直接照抄：

```jsp
<%-- content_stdind_dsnapp.jsp:31 --%>
<%System.out.println("content_stdind_dsnapp.jsp"); %>
```

**推荐打点位置**（能一次看清整条链路）：

```java
// ① Service 入口（src/.../StdIndNyusatsuIraiJohoService.java 的 execute 第一行）
System.out.println(">>> execute start form=" + form);

// ② Service 放数据之前（storeResultBean 前）
System.out.println(">>> NYUSATSUJOHO_UP=" + nyusatsuIraiJohoMap);
```

```jsp
<%-- ③ JSP 第一行：确认到底有没有进来、request 里有什么 --%>
<%
  System.out.println(">>> " + request.getRequestURI()
      + " | NYUSATSUJOHO_UP=" + request.getAttribute("NYUSATSUJOHO_UP")
      + " | wfDraftInfMap=" + request.getAttribute("wfDraftInfMap"));
%>
```

**前提**：这些输出必须能到你眼前 → Tomcat 必须是 Eclipse 启动的（§1 确认②），
并且看的是正确的 Console（§1 确认③）。
**如果 Tomcat 不是 Eclipse 启的**，把 stdout 导到文件即可：
```bash
catalina.sh run  > /tmp/tomcat.out 2>&1     # Linux
catalina.bat run > D:\tomcat.out 2>&1       # Windows
# 然后 tail -f /tmp/tomcat.out 或直接打开看
```

### 3.4 【最有效】打断点

| 断点位置 | 能看到什么 |
|---|---|
| `src/.../StdIndNyusatsuIraiJohoService.java:118`（`execute` 开头） | form 里有哪些请求参数、是否真的被调用 |
| `src/.../BidIraiEntity.java:1054`（`getNyusatsuIraiJoho`） | 最终 SQL 和参数 |
| `src/.../OsatsuShosaiService.java:83`（`execute` 开头） | 完整 Service 流程（小而完整，适合练手） |
| **`BaseAction.getAssociateServiceName`**（在 `WEB-INF/lib/rug_web.jar` 里，没有源码也能打断点） | ★ **URL → Service 名的映射过程**，一看就懂框架怎么查表 |
| JSP 行号（先访问一次让它编译，再打断点） | JSP 里 request 到底有没有数据 |

**必须用 Debug 模式启动**：Servers 视图里右键 Tomcat → `Debug`（不是 Start）。
JSP 断点要求该 JSP 已被访问过一次（编译成 servlet 后才可断）。

---

## 4. 改了代码没生效？按这个清单排

1. **Java 改了**：`Project → Clean...` → 右键 Server → `Restart`（本工程输出目录是 `src`，Clean 才能保证重新编译）
2. **JSP 改了**：一般热加载；不行就重启 Tomcat，并**清浏览器缓存**（JSP 会被缓存）
3. **确认部署的是这份代码**：双击 Server → Server Locations → 看 Deploy path（`Use workspace metadata` 时在
   `workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp*/wtpwebapps/ebid/`）
   → 去那里打开对应 JSP，确认你的修改**真的被复制过去了**
4. **改了 `struts-config.xml` / `action-service.xml` / `tiles-*.xml`**：这些是启动时读取的，**必须重启 Tomcat**
5. **改了 `log4j.xml`**：同上，必须重启（log4j 只初始化一次）

---

## 5. 常见坑

| 现象 | 原因 / 处理 |
|---|---|
| 控制台一个字都没有 | ① log4j 无 ConsoleAppender（§0.1）② Tomcat 不是 Eclipse 启的（§0.3）③ 看错 Console tab（§1③） |
| 找不到 JSP 文件 | 先看网页源码 `画面名：`（§2 办法 A）；或 F12 抓 `.do` 反查（§2 办法 B）；`Ctrl+Shift+R` 通配搜索 |
| forward 的 path 不是文件名 | 那是 tiles 定义名，去 `WebContent/jsp/layout/*.xml` 查 `definition`，再看 `inner1/inner2` |
| 页面是运行时"拼"出来的 | 搜 `"前缀_" + 变量`（如 `"process_" + sheetId`）→ 去 `tiles-defs.xml` 找同名 `putList` |
| 日志文件找不到 | 找启动参数 `-Dlog.home=`（§3.1） |
| 仓库里搜不到 SQL 原文 | SQL 在 classpath 的 `buyer-sql-statements.xml`，**不在仓库**，去部署目录 `WEB-INF/classes` 找 |
| 页面 URL 是 `/pcmv2std/develop/ebid/...` | 正常，context-root 写在 `.settings/org.eclipse.wst.common.component` |
| 走到 SSO 跳转 10.10.78.122 | `WebContent/WEB-INF/web.xml` 里 ScpfFilter 的配置，是登录门户地址，不是你的调试目标 |

---

## 6. 一页速查

```
【找不到 JSP】
  网页右键→查看源代码→搜"画面名"        （735 个 JSP 都自带路径）
  F12 Network 抓 .do → struts-config.xml path → forward → .jsp 或 tiles definition
  tiles 定义名 → rg "definition name=xxx" WebContent/jsp/layout/*.xml → inner1/contents 就是内容 JSP
  运行时拼的页面 → 搜 "前缀_" + 变量 → tiles-defs.xml 的 putList

【控制台没日志】
  1) log4j 只写文件：${log.home}/ebid-web.log（先找 -Dlog.home）
  2) 想上控制台 → 改 src/log4j.xml 加 ConsoleAppender → Clean + Restart
  3) 想立刻确认 JSP 有没有执行 → JSP 第一行 System.out.println（本项目惯例）
  4) 想看 URL→Service 怎么映射 → 断点 BaseAction.getAssociateServiceName（rug_web.jar）

【改代码不生效】
  Java: Clean + Restart；JSP: 重启 + 清缓存；配置 xml: 必须重启
  确认 Server 的 Deploy path 里真的是你改的那份
```

---

## 7. 实战演练：`to_sup_bid_list.do` → JSP（照着做一遍）

### 7.1 先找是谁发的这个请求

```bash
cd E:/agent/pi/day1109/ebid
rg -n "to_sup_bid_list" -g '*.jsp' -g '*.js' -g '*.xml'
```
结果：
- `WebContent/jsp/supplier/contents/result/data_bidlst.jsp:36`  `<html:form styleId="SRCH_ITEM" action="/to_sup_bid_list.do">` ← **表单就在这个 JSP 里**
- `WebContent/jsp/supplier/js/result/bidlst.js:79` `document.getElementById("SRCH_ITEM").action = doPath+"/to_sup_bid_list.do"` ← JS 改 action 后提交
- `WebContent/jsp/layout/menu.xml:133` `link="to_sup_bid_list.do"` ← 也可能是菜单直接点的

> 经验：**一个 `.do` 被谁调用，直接 `rg` 这个字符串**，比在浏览器里猜快。

### 7.2 查两张表（本项目的核心套路）

```bash
# ① URL → 页面
rg -n 'path="/to_sup_bid_list"' -A 2 WebContent/WEB-INF/struts-config.xml
# ② URL → Service
rg -n 'name="/to_sup_bid_list"' -A 2 WebContent/WEB-INF/xml/action-service.xml
```
结果：

```xml
<!-- struts-config.xml:3993 -->
<action path="/to_sup_bid_list" extends="/base" parameter="role=SRFQREPLY">
    <forward name="kekkaichiran" path="id_sup_bid_list"/>   ← 不是 .jsp！是 tiles 定义名
</action>

<!-- action-service.xml:2371 -->
<action name="/to_sup_bid_list">
    <servicename value="KekkaIchiranService" />
</action>
```

### 7.3 forward 名 → tiles 定义 → 真正的 JSP

```bash
rg -n 'definition name="id_sup_bid_list"' -A 8 WebContent/jsp/layout/*.xml
```
```xml
<!-- tiles-supplier.xml:219 -->
<definition name="id_sup_bid_list" extends="sup.bid.base">
    <put name="id"       value="id_sup_bid_list" />
    <put name="title"    value="title_bid" />
    <put name="button"   value="/jsp/supplier/contents/result/button_bidlst.jsp" />   ← 按钮条
    <put name="contents" value="/jsp/supplier/contents/result/data_bidlst.jsp" />     ← ★主体 JSP
</definition>
```

**拼装链**（`extends` 继承 + `put` 覆盖，和第 3 章讲的一样）：

```
id_sup_bid_list
  └ extends sup.bid.base  (tiles-supplier.xml:135, put app_style/sub_menu/error)
       └ extends default.base (tiles-defs.xml:9, path=/jsp/layout/base_layout.jsp, body=base_contents.jsp)

base_layout.jsp:203  <tiles:insert attribute='body'> → base_contents.jsp
base_contents.jsp    <tiles:insert attribute='title'|'button'|'contents'|...>
                       ├ title    → base_title.jsp      (title_bid 的 TITLE_ITEM)
                       ├ button   → button_bidlst.jsp
                       └ contents → data_bidlst.jsp     ★你要找的 JSP
```

### 7.4 对账：Service 给的数据 == JSP 用的 bean

`src/jp/co/toshiba_sol/esup/bid/supplier/service/osatsukekka/KekkaIchiranService.java`：

| Service（storeResultBean 的 key） | 行号 | JSP `data_bidlst.jsp` 里的用法 |
|---|---|---|
| `kekka`（応札結果一覧列表） | `:822` | `:217` `<logic:iterate id="item" name="kekka">` → `BANGO/HATSUCD/TYOHYOKBN...` |
| `rscount`（记录数） | `:846` | `:91` `<bean:write name="rscount" property="recordCount"/>` |
| `returnmessage` / `errormessage` | `:852/:855` | `:44` / `:53` |
| `selectform`（検索条件回填） | `:834` | 表单回填 |
| `kategori`/`hyokaList`/`kigyoName`/`pageData`/`date`/`pdfMaxSize` | `:815/:809/:802/:828/:840/:800` | 下拉框、分页 |
| `setForwardString("kekkaichiran")` | `:861` | ←→ `struts-config.xml:3994` `<forward name="kekkaichiran">` ✅ |

Service 里查数据的实体：
```java
KekkaIchiranEntity  kekkaEntity = new KekkaIchiranEntity(dao);     // :641 応札結果一覧
CategoryComboEntity kategori... = new CategoryComboEntity(dao);    // :638 カテゴリ
HyokaComboxEntity   combox...   = new HyokaComboxEntity(dao);      // :644 評価
```
→ 再往下就是 `SqlSet.getSupSql(SqlConst.XXX)` → SQL 文本（部署环境的 `*-sql-statements.xml`）→ 表。

### 7.5 结论

```
to_sup_bid_list.do
  ├ struts-config.xml:3993 → forward "kekkaichiran" → id_sup_bid_list
  │    └ tiles-supplier.xml:219 → contents = /jsp/supplier/contents/result/data_bidlst.jsp   ★JSP
  │         （button = button_bidlst.jsp，title = title_bid，外框 base_layout.jsp）
  └ action-service.xml:2371 → KekkaIchiranService
       ├ :822/:846/:834... storeResultBean(kekka/rscount/selectform...) → request
       ├ :861 setForwardString("kekkaichiran") → 与 forward 对上
       └ :641 KekkaIchiranEntity → SqlConst → SQL → 応札結果テーブル
```

---

## 8. Windows 上没有 `rg` 怎么办（以下命令全部实测通过）

你的 cmd 提示 `'rg' は、内部コマンド...認識されていません` = 没装 ripgrep。三种替代：

### 方案 1：`findstr`（Windows 自带，零安装，推荐先用这个）

```bat
:: 递归搜索所有 jsp/js/xml（等价 rg -n "to_sup_bid_list" -g '*.jsp' -g '*.js' -g '*.xml'）
E:\agent\pi\day1109\ebid> findstr /s /n /i "to_sup_bid_list" *.jsp *.js *.xml

:: 搜单个/指定目录的文件（路径用反斜杠没问题）
> findstr /n /i "id_sup_bid_list" WebContent\jsp\layout\*.xml
> findstr /n /i "to_sup_bid_list" WebContent\WEB-INF\struts-config.xml
```
参数：`/s` 递归、`/n` 显示行号、`/i` 忽略大小写。
⚠️ **findstr 没有 `-A`（不显示后几行）** → 记下行号，Eclipse 里 `Ctrl+G` 跳过去看上下文。

实测输出（`to_sup_bid_list`）：
```
WebContent\jsp\layout\menu.xml:133: ... link="to_sup_bid_list.do"
WebContent\jsp\supplier\contents\result\data_bidlst.jsp:36: <html:form ... action="/to_sup_bid_list.do">
WebContent\jsp\supplier\js\result\bidlst.js:79: ...action=doPath+"/to_sup_bid_list.do";
WebContent\WEB-INF\struts-config.xml:3993: <action path="/to_sup_bid_list" ...>
WebContent\WEB-INF\xml\action-service.xml:2371: <action name="/to_sup_bid_list">
```

### 方案 2：`grep`（如果有的话，`grep --version` 试一下）

```bat
:: 递归 + 可以带 -A 显示后几行
> grep -rn "to_sup_bid_list" --include=*.jsp --include=*.js --include=*.xml .
> grep -n -A8 "id_sup_bid_list" WebContent/jsp/layout/*.xml      ← 路径必须用正斜杠 /
> grep -n -A2 "to_sup_bid_list" WebContent/WEB-INF/struts-config.xml
> grep -rln "class OsatsuShosaiService" src                      ← 等价 rg -l
```
⚠️ **grep 在 Windows 上把 `\` 当转义符**，写 `WebContent\jsp\...` 会变成 `WebContentjsplayout...` 报错，**一律用 `/`**。

### 方案 3：装 ripgrep（一劳永逸，教程里所有 `rg` 命令直接能用）

你的机器没有 winget，任选一种：
- 有 scoop：`scoop install ripgrep`
- 有 choco：`choco install ripgrep`
- 手动：GitHub → `BurntSushi/ripgrep` releases → 下 `ripgrep-*-x86_64-pc-windows-msvc.zip`
  → 解压到比如 `D:\tools\ripgrep` → 把该目录加进 `PATH`（系统属性→环境变量）→ **重开终端**
  → `rg --version` 验证

> 另：本机其实有个 rg：`C:\Users\jiangyuchang\.pi\agent\bin\rg.exe`，
> 但它只在 pi agent 的 PATH 里，你的 cmd 没有 → 不如自己装一个。

### ⚠️ cmd 的两个坑（我之前给的命令踩了）

1. **cmd 不认单引号**：`grep -n 'pattern' file` 在 cmd 里会把 `'` 当字面量，匹配不到。
   **一律用双引号**：`grep -n "pattern" file`、`findstr /n "pattern" file`
2. **路径分隔符**：`findstr` 用 `\` 没问题；`grep` 必须用 `/`

### 对照表：教程里的 `rg` → Windows 命令

| 教程里的写法（Linux/Git Bash） | cmd 里用这个 |
|---|---|
| `rg -n "关键字"` | `findstr /n /i "关键字" 文件路径` |
| `rg -n "关键字" -g '*.jsp'` | `findstr /s /n /i "关键字" *.jsp` |
| `rg -rn "关键字" -g '*.jsp' -g '*.js'` | `findstr /s /n /i "关键字" *.jsp *.js` |
| `rg -n "pattern" -A 8 文件` | `grep -n -A8 "pattern" 文件`（正斜杠路径）或 findstr 后自己 Ctrl+G 跳行 |
| `rg -l "class XxxService" src` | `grep -rln "class XxxService" src` 或 `findstr /s /n /i "class XxxService" src\*.java` |
| `rg -n "definition name=\"xxx\"" -A 8 WebContent/jsp/layout/*.xml` | `findstr /n /i "definition name" WebContent\jsp\layout\*.xml` 再肉眼看，或 `grep -n -A8 "definition name" WebContent/jsp/layout/*.xml` |
