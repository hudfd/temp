# `/to_sup_item_list.do`（入札案件一覧）点"検索"之后，数据到底怎么来的

> 仓库：`E:/agent/pi/day1109/ebid`
> 页面：サプライヤ → 入札案件一覧（供应商 → 入标案件一览）
> 命令都给 Windows cmd 版（`findstr` / `grep`），已实测。
> ★ 本文重点：**先纠正你的理解模型**，再用这一个页面把整套机制讲透。

---

## 0. 先说结论：你的理解对了一半，有 6 处要修正

| # | 你的理解 | 实际情况 |
|---|---|---|
| 1 | "JSP 拿到 form 表单，传回 service" | ✅ 对，但**中间隔着两层框架**：Struts 的 `BaseAction` + `action-service.xml`，Service 不是被 JSP 直接调的 |
| 2 | "Service 里有一个 map，把前端 form 的每个字段作为 key 放进去" | ⚠️ **这个 map 是框架提前组装好的**，Service 只是**读**它（`MapUtils.getString(form,"HD_XXX")`）。而且 Service 里有**两个不同的 Map**：条件 map（`nyusatsuForm`）和结果 map（`nyusatsuMap`），**结果不会塞回 form** |
| 3 | "以 form 为查询条件去查 sql" | ✅ 方向对，但**条件不是拼进 SQL 字符串的**，而是：`SQL 片段 + 占位符参数 List`（预编译绑定）。空条件根本不加（`createWherePhrase` 逐个判断非空） |
| 4 | "把查到的 put 到 map 里为值" | ⚠️ `dao.select()` 返回的是 **`List<Map>`（每行一个 Map，列名→列值）**，不是一个 map。Service 再把它**拆成 3 份**：列表 / 分页 / 总件数 |
| 5 | "最后把这个 map.get() 返回到前端 jsp" | ❌ **Service 不 return 数据**，它 `return CommonDataSet`（一个"暂存箱"），里面装的是 N 个 `storeResultBean(key, 数据, REQUEST)` + 1 个 `setForwardString(forward名)`。由**框架**把它们 `request.setAttribute(key, 数据)` 再 forward 到 JSP |
| 6 | （没提到） | ❌ 漏了 **两步框架动作**：① 进 Service 前，框架把「请求参数 + 登录用户信息 + Locale + 时区」合成 form Map；② 出 Service 后，框架把 CommonDataSet 灌进 request、再按 forward 名找页面 |

**一句话修正版**：

> JSP 表单 → **框架**把参数+用户信息合成 `form` Map → 按 action 查 `action-service.xml` 拿到 Service 名 → Service **读 form 构造条件** → Entity 用「SQL 片段 + 参数 List」查库，拿到 `List<Map>` → Service 拆成列表/分页/件数 → **`storeResultBean` 放进 CommonDataSet + `setForwardString`** → **框架** `request.setAttribute` + `findForward` → tiles → JSP 用 `<logic:iterate name="nyusatsu">` 渲染。

---

## 1. 全景时序（10 步，全部带行号）

```
① 检索按钮   button_itemlst.jsp:206  onclick="Submit_Form(...)"
② JS 搬条件  item.js:31-53  把用户输入(SET_SRCHDATA) 拷进隐藏域表单 SRCH_ITEM 的 HD_* 字段 → submit
③ 表单提交   data_itemlst.jsp:33  <form name="SRCH_ITEM" action="/to_sup_item_list.do">
④ Struts     struts-config.xml:73  /base → BaseAction + BaseMapActionForm（Map 型 form-bean :13-14）
                └ :3980 /to_sup_item_list → <forward name="nyusatsuichiran" path="id_sup_item_list"/>
⑤ action-service.xml:2361 → servicename = NyusatsuIchiranService
⑥ 【框架】组装 form Map：请求参数 + 登录用户(USERINFO) + Locale + 时区
⑦ Service    NyusatsuIchiranService:124 execute(acname, form, other)
                └ :136 建条件 Map，:144 判断是菜单进入(给默认值) 还是表单提交(从 form 拷)
⑧ Entity     :548 dao.open(DENSI_DB) → :562 nyusatsuEntity.getNyusatsuIraiList(nyusatsuForm)
                └ Entity:244 SQL片段 + :280 createWherePhrase(条件→参数List) + :325 分页查询
                └ Entity:483 dao.select(sql, params) → 返回 List<Map>
                └ Entity:339-347 拆成 nyusatsudata / pagedata / recordCount
⑨ Service    :640~680 storeResultBean ×8 → :685 setForwardString("nyusatsuichiran") → return dset
⑩【框架】request.setAttribute ×8 → findForward("nyusatsuichiran") → id_sup_item_list
   → tiles-supplier.xml:90 → contents = data_itemlst.jsp → <logic:iterate name="nyusatsu"> 渲染
```

---

## 2. 逐步拆解

### 步骤步骤①②③：检索条件是怎么从"输入框"走到"HTTP 请求"的

这个页面有个特殊点：**检索输入框和提交表单不在同一个 JSP 片段里**。

- tiles 把页面拆成 `button` 和 `contents` 两块（见步骤⑩）：
  - `button_itemlst.jsp` = 检索条件输入区（输入框、日历、检索按钮）
  - `data_itemlst.jsp` = 列表显示区 + **真正的 `<form>`**
- 所以点检索时要靠 JS 搬运：

```js
// WebContent/jsp/supplier/js/item/item.js:31
function Submit_Form(doPath) {
    document.SRCH_ITEM.HD_DISPNUM.value  = document.SRCH_ITEM.DISPNUM_SEL.value;
    document.SRCH_ITEM.HD_SORT_SEL.value = document.getElementById("SET_SRCHDATA").SORT_SEL.value;
    document.SRCH_ITEM.HD_BIDNUMBER.value= document.getElementById("SET_SRCHDATA").BIDNUMBER.value;
    document.SRCH_ITEM.HD_ENDDATE_START.value = ...;
    ...
    document.SRCH_ITEM.action = doPath + "/to_sup_item_list.do";   // item.js:52
    document.SRCH_ITEM.target = "_self";
    document.SRCH_ITEM.submit();
}
```

表单在 `data_itemlst.jsp:33`：
```jsp
<form name="SRCH_ITEM" id="SRCH_ITEM" method="POST" action="/to_sup_item_list.do" >
```
隐藏域（`:392-412`）负责把上次的条件带回来：
```jsp
<html:hidden name="selectform" property="HD_ENDDATE_START"/>
<html:hidden name="selectform" property="HD_BIDNUMBER"/>
<html:hidden name="selectform" property="HD_HATSUNAME"/>
...
```

> 🔑 **关键点**：JSP 的 `<html:hidden name="selectform" property="HD_BIDNUMBER"/>`
> 说明 `selectform` 是个 request 里的 Map，**条件就是靠它在页面之间来回传递的**（见步骤⑨）。

### 步骤④：Struts 怎么接住这个 URL

```xml
<!-- struts-config.xml:70-76 -->
<action path="/base"
    type="jp.co.toshiba_sol.wakaba.web.BaseAction" name="BaseActionForm"
    scope="request" validate="false" />
```
```xml
<!-- struts-config.xml:13-14  form-bean 是 Map 型的！ -->
<form-bean name="BaseActionForm" type="jp.co.toshiba_sol.wakaba.web.BaseMapActionForm" />
```
```xml
<!-- struts-config.xml:3980 -->
<action path="/to_sup_item_list" extends="/base" parameter="role=SRFQREPLY">
    <forward name="nyusatsuichiran" path="id_sup_item_list"/>   ← 不是 .jsp，是 tiles 定义
</action>
```

- `extends="/base"` = 复用父 action 的 `type/form-bean`
- `parameter="role=SRFQREPLY"` = **权限角色**（供应商才能访问），框架在进 Service 前校验
- `BaseMapActionForm` = **Map 结构的 ActionForm**：请求里所有参数（`HD_*`）自动进一个 Map

> 我反编译了 `rug_web.jar` 里的 `BaseAction.class`，能看到它的动作：
> ```
> getAssociateServiceName   ← 查 action-service.xml 拿 servicename
> getSessionAttributes / sessionInfo / UsedUserInfoKey / UsedLocaleKey   ← 组装用户信息
> executeService(BaseService, acname, form, other, ...)                   ← 调 Service
> (CommonDataSet, HttpServletRequest, HttpServletResponse, Map) ← 把结果灌进 request
> getForward / findForward / "Forwarding name : "                         ← 按 forward 名找页面
> ```
> **这就是"⑥组装 form"和"⑩灌回 request"的执行者。**

### 步骤⑤：action-service.xml → Service 名

```xml
<!-- WebContent/WEB-INF/xml/action-service.xml:2361 -->
<action name="/to_sup_item_list">
    <servicename value="NyusatsuIchiranService" />
</action>
```
→ `ServiceLocator.lookup("NyusatsuIchiranService")` → 没在 service-locator.xml 登记 → 走兜底 `.*` → `Remote_Ebid` → 按**类简单名同名**实例化：
`src/jp/co/toshiba_sol/esup/bid/supplier/service/nyusatsuanken/NyusatsuIchiranService.java` ✅（这个在仓库里，696 行）

### 步骤⑥★：form Map 是谁拼的（你漏掉的这一步）

**不是 Service 拼的**，是框架在调用 `execute()` 之前就准备好了。它包含：

| 来源 | 内容 | 谁放的 |
|---|---|---|
| HTTP 请求参数 | `HD_BIDNUMBER`、`HD_ENDDATE_START`、`HD_DISPNUM`、`HD_PAGENUM`… | `BaseMapActionForm`（Map 型 form-bean） |
| 登录用户信息 | 供应商代码 `JUCHUCD`、`IDTUID`、所在国 `KUNI_ID`… | `BaseAction` 从 session 取（`UsedUserInfoKey`） |
| 语言 | `USED_LOCALE_KEY` → Entity 里当 `LOCALE` 用 | 同上 |
| 时区 | `TIME_ZONE_ID`（VR5.0 加的，日期条件要转时区） | 同上 |
| 其它 | `ACNAME`、`ORIGINAL_APP_EVENT_ID` 等 | 框架 |

Service 里只做一件事：**读**它（`NyusatsuIchiranService:205-287`）：
```java
nyusatsuForm.put("HD_DISPNUM",      MapUtils.getString(form, "HD_DISPNUM"));
nyusatsuForm.put("HD_ENDDATE_START",MapUtils.getString(form, "HD_ENDDATE_START"));
nyusatsuForm.put("HD_BIDNUMBER",    MapUtils.getString(form, "HD_BIDNUMBER"));
...
```

### 步骤⑦：Service 里"条件 Map"的两种来源

```java
// NyusatsuIchiranService.java:124
public CommonDataSet execute(String acname, Map form, Map other) {

    CommonDataSet dset = new CommonDataSet();          // ← 暂存箱，不是数据
    Map nyusatsuForm = new HashMap();                  // :136 ← 这是【条件 Map】

    if (StringUtils.equals(null, MapUtils.getString(form, "HD_DISPNUM"))) {
        // 从菜单点进来的（没有检索条件）→ 全给默认值
        nyusatsuForm.put("HD_DISPNUM", "10");          // :148  每页10条
        nyusatsuForm.put("HD_SORT_SEL", "ENDDATE");    //       默认按截止日升序
        nyusatsuForm.put("HD_PAGENUM", "1");           //       第1页
        nyusatsuForm.put("HD_KUBUNCODE", "SIMEI");     //       默认"指名入札"
        ...
    } else {
        // 表单提交的 → 从 form 逐个拷
        nyusatsuForm.put("HD_DISPNUM", MapUtils.getString(form, "HD_DISPNUM"));   // :205
        ...
    }
```
> 🔑 **`nyusatsuForm`（条件）和 `form`（框架给的原始 Map）是两个东西；
> 后面查出来的结果会放进第三个 Map（`nyusatsuMap`）。三者互不混用。**

### 步骤⑧：Entity 查库 —— 条件怎么进 SQL

```java
// NyusatsuIchiranService.java:548/529/562
dao.open(Constants.DENSI_DB);                                  // 打开"电子入札"库
NyusatsuIchiranEntity nyusatsuEntity = new NyusatsuIchiranEntity(dao);
nyusatsuMap = nyusatsuEntity.getNyusatsuIraiList(nyusatsuForm);
```

Entity 里（`src/.../bid/supplier/entity/NyusatsuIchiranEntity.java`）：

```java
// :244  取 SQL 片段（指名入札 / 公开入札 两套）
if ("SIMEI".equals(map.get("HD_KUBUNCODE"))) {
    selectSQL1 = SqlSet.getSupSql("nyusatsuichiran_select001_s");
    selectSQL2 = SqlSet.getSupSql("nyusatsuichiran_select002_s");
    selectSQL3 = SqlSet.getSupSql("nyusatsuichiran_select003_s");
} else { ..._k 版本... }

// :280  ★ 动态 WHERE —— 条件值进的是参数 List，不是 SQL 字符串
this.createWherePhrase(searchMap, sqlBuf, paraList);

// :325  分页查询
PagingResult pagingResult = this.getPagingListW(sqlBuf.toString(), selectSQL3,
                                    pagenum, dispnum, orderBy, paraList.toArray(), priority);
```

`createWherePhrase`（`:896` 起）长这样 —— **非空才追加**：
```java
if (!"".equals(MapUtils.getString(searchMap, "HD_ENDDATE_START"))) {
    paraList.add(MapUtils.getString(searchMap, "TIME_ZONE_ID"));   // 时区
    paraList.add(MapUtils.getString(searchMap, "HD_ENDDATE_START")); // ★值进参数表
    selectSQL.append(SqlSet.getSupSql("nyusatsuichiran_select_where003"));  // 只追加 SQL 片段（带 ? 占位）
}
if (!"".equals(MapUtils.getString(searchMap, "HD_BIDNUMBER"))) {
    paraList.add(SqlUtil.appendPercentSign(searchMap, "HD_BIDNUMBER"));  // 模糊查询自动加 %
    ...
}
```

真正执行（`:483`）：
```java
List result = (List) dao.select(sqlBuff.toString(), param);   // ★ 返回 List<Map>
```

**`dao.select()` 的返回结构**（这是你模型里最关键的一处修正）：
```
List
 ├─ Map { BANGO:"123", HATSUCD:"A01", ENDDATE:"2025/01/10", KENMEI:"..." }   ← 第1行
 ├─ Map { BANGO:"124", ... }                                                  ← 第2行
 └─ ...
```
即：**每行一个 Map，key = SQL 的列别名，value = 列值**。所以 JSP 里才能
`<bean:write name="item" property="BANGO"/>`。

Entity 最后把结果**拆成三份**（`:339-347`）：
```java
Map nyusatsuListMap = new HashMap();
nyusatsuListMap.put("nyusatsudata", rsList);        // 列表 List<Map>
nyusatsuListMap.put("pagedata",    pagedata);       // 分页 PageData 对象
nyusatsuListMap.put("recordCount", rsCountMap);     // 总件数 {recordCount:"57"}
return nyusatsuListMap;
```

### 步骤⑨：Service —— 不 return 数据，return "暂存箱"

```java
// NyusatsuIchiranService.java:640 ~ 685
dset.storeResultBean("pdfMaxSize", pdfMaxSize,      CommonDataSet.REQUEST);  // :640 PDF上限
dset.storeResultBean("kigyoName", kigyNameArrayList,CommonDataSet.REQUEST);  // :643 依頼元下拉
dset.storeResultBean("kategori",  kategoriArrayList,CommonDataSet.REQUEST);  // :649 カテゴリ下拉
dset.storeResultBean("nyusatsu",  nyusatsuArrayList,CommonDataSet.REQUEST);  // :655 ★列表数据
dset.storeResultBean("pageData",  pagedata,         CommonDataSet.REQUEST);  // :661 ★分页
dset.storeResultBean("selectform",nyusatsuForm,     CommonDataSet.REQUEST);  // :665 ★检索条件(回填用)
dset.storeResultBean("date",      nowDateMap,       CommonDataSet.REQUEST);  // :670 当前时间
dset.storeResultBean("rscount",   record,           CommonDataSet.REQUEST);  // :674 ★总件数
dset.storeResultBean("errormessage", returnMessage, CommonDataSet.REQUEST);  // :680 再回答消息

dset.setForwardString("nyusatsuichiran");                                 // :685 ★决定跳哪
return dset;                                                              // :693 返回的是 dset！
```

> 🔑 **`storeResultBean(key, value, REQUEST)` = "把这个 key/value 对，放到 request 作用域"**
> （`CommonDataSet` 里还有 `SESSION`、`APPLICATION` 两个作用域常量）。
> 这就是你理解里的"put 到 map 里"，只不过**目标是 CommonDataSet，key 由 Service 自己起，不是表单字段名**。

### 步骤⑩：框架 → forward → tiles → JSP 渲染

```
BaseAction 拿 dset：
  request.setAttribute("nyusatsu",  List<Map>)      ← 就是 <logic:iterate name="nyusatsu"> 的数据源
  request.setAttribute("selectform", nyusatsuForm)  ← 条件回填
  request.setAttribute("rscount",   {recordCount:"57"})
  request.setAttribute("pageData",  PageData)
  ...共 8 个
  findForward("nyusatsuichiran")  → struts-config.xml:3981 → id_sup_item_list

tiles-supplier.xml:90
  <definition name="id_sup_item_list" extends="sup.item.base">
      <put name="title"    value="title_item"/>
      <put name="button"   value="/jsp/supplier/contents/item/button_itemlst.jsp"/>   ← 检索输入区
      <put name="contents" value="/jsp/supplier/contents/item/data_itemlst.jsp"/>     ← ★列表 JSP
  </definition>
```

`data_itemlst.jsp` 渲染：

| JSP 写法 | 行 | 数据来自 |
|---|---|---|
| `<bean:define id="map" name="selectform" type="java.util.Map"/>` | `:30` | `storeResultBean("selectform")` → 拿来回填条件 |
| `<bean:write name="rscount" property="recordCount"/>` | `:77` | `storeResultBean("rscount")` |
| `<logic:iterate id="item" name="nyusatsu" indexId="index">` | `:185` | `storeResultBean("nyusatsu")` ← **List<Map> 逐行渲染** |
| `<html:hidden name="selectform" property="HD_BIDNUMBER"/>` | `:396` | 条件写回页面，下次检索还能带上 |
| `<sup:page linkNumMax="10"/>` | `:70` | 自定义标签 → `PagingTag.java:56` `name="pageData"`、`:149` `request.getAttribute("pageData")` ← **标签也是从 request 拿** |

---

## 3. 数据字典：8 个 bean 全对照

| Service 的 storeResultBean key | 行号 | 类型 | JSP 用法 |
|---|---|---|---|
| `nyusatsu` | `:655` | `List<Map>`（每行=一个案件） | `data_itemlst.jsp:185 <logic:iterate name="nyusatsu">` → `item.BANGO/HATSUCD/ENDDATE...` |
| `selectform` | `:665` | `Map`（检索条件） | `:30 bean:define`、`:396-412 html:hidden` 回填、`:109/:252 logic:equal` 判断指名/公开 |
| `rscount` | `:674` | `Map {recordCount:"57"}` | `:77` 显示件数 |
| `pageData` | `:661` | `PageData` 对象 | `:70 <sup:page>` → `PagingTag:149` |
| `kigyoName` | `:643` | `List`（依頼元下拉） | `button_itemlst.jsp:89 <sup:select cataName="kigyoName">` |
| `kategori` | `:649` | `List`（カテゴリ下拉） | `button_itemlst.jsp` 的カテゴリ下拉 |
| `date` | `:670` | `Map {nowakdate:...}` | 标题栏显示时间（`base_title.jsp:104`） |
| `errormessage` | `:680` | `String` | `data_itemlst.jsp:36` 再回答结果消息 |
| `pdfMaxSize` | `:640` | `String` | PDF 下载上限提示 |

---

## 4. SQL 和表在哪

```java
SqlSet.getSupSql("nyusatsuichiran_select001_s")     // Entity:244
   ↓
SqlSet.java:68  →  new SqlXMLParser().parse(SqlXMLParser.SUPPLIER_XML)
   ↓
SqlXMLParser.java:50  SUPPLIER_XML = "/supplier-sql-statements.xml"   ← ⚠️ 不在本仓库（部署资源）
```

**SQL key 清单**（去 `supplier-sql-statements.xml` 里搜这些就能看到原文）：
```
nyusatsuichiran_select001_s / _k     ← SELECT 主体（指名 / 公开）
nyusatsuichiran_select002_s / _k     ← JOIN + Locale
nyusatsuichiran_select003_s / _k     ← 件数统计
nyusatsuichiran_select_where001      ← WHERE 开头
nyusatsuichiran_select_where003      ← AND 回答提出期限 >= ?
nyusatsuichiran_select_where004      ← AND 回答提出期限 <= ? (+ 23:59)
nyusatsuichiran_select_where00x      ← 入札依頼番号 / 依頼元 / カテゴリ / 品名 / 入札開始日 …各条件
```

**表**（从代码可见的线索，确切表名要看上面那个 SQL 文件）：
- `Entity:294/296` 排序用到 `page_view.HATSU_CD` → 有个 **`page_view` 视图/别名**
- `paraList.add(juchucd)` → 按**供应商代码**过滤（受注者选択表 `BID_CHOOSE_JUCHU` 系）
- 库名：`Constants.DENSI_DB = "DENSI"`（电子入札）、`SYSTEMKANRI_DB = "SYSTEMKANRI"`（分类下拉走这个库，`:598`）

> 找不到 SQL 原文时的查法：
> ```cmd
> > dir /s /b supplier-sql-statements.xml        （部署目录 / WEB-INF\classes）
> > findstr /n /i "nyusatsuichiran_select001_s" supplier-sql-statements.xml
> ```

---

## 5. 一张图记住"两个 Map + 一个暂存箱"

```
   ┌─────────────── 框架组装 ───────────────┐
   │ 请求参数 HD_*  ┐                       │
   │ 登录用户信息    ├→ form (Map)           │  ← Service 只读
   │ Locale / 时区  ┘                       │
   └───────────────────┬───────────────────┘
                       ▼  Service:205-287 拷贝/给默认值
              nyusatsuForm (条件 Map)  ──────────────┐
                       ▼  Entity:280 createWherePhrase│
        SQL 片段 + paraList(占位参数) → dao.select     │
                       ▼                              │
        List<Map>（每行一个 Map）                      │
                       ▼  Entity:339-347 拆三份        │
        nyusatsudata / pagedata / recordCount          │
                       ▼                              │
   ┌──────────────────────────────────────┐          │
   │ CommonDataSet（暂存箱 dset）           │ ◄────────┘ 条件也存进去
   │  storeResultBean("nyusatsu", ...)     │
   │  storeResultBean("selectform", ...)   │   ← :665 条件原样存回，供 JSP 回填
   │  storeResultBean("rscount", ...)      │
   │  setForwardString("nyusatsuichiran")  │   ← :685 决定跳哪
   └──────────────────┬───────────────────┘
                      ▼  框架：request.setAttribute(key, value) ×8
                    request
                      ▼  findForward("nyusatsuichiran") → tiles id_sup_item_list
                 data_itemlst.jsp
                      ▼
        <logic:iterate name="nyusatsu">  逐行渲染 <bean:write name="item" property="BANGO"/>
```

**记住三个名字**：
- `form` —— 框架给的**原始请求+用户信息**（只读）
- `nyusatsuForm` —— Service 自己整理的**检索条件**
- `CommonDataSet dset` —— Service 往外**递东西的箱子**（数据 + forward 名）

---

## 6. 自己动手验证

```cmd
:: ① 两张表
> findstr /n /i "to_sup_item_list" WebContent\WEB-INF\struts-config.xml
> findstr /n /i "to_sup_item_list" WebContent\WEB-INF\xml\action-service.xml

:: ② Service 类 + 往外递了什么
> findstr /n /i "storeResultBean" src\jp\co\toshiba_sol\esup\bid\supplier\service\nyusatsuanken\NyusatsuIchiranService.java
> findstr /n /i "setForwardString"  src\jp\co\toshiba_sol\esup\bid\supplier\service\nyusatsuanken\NyusatsuIchiranService.java

:: ③ JSP 要哪些 bean（和②对账）
> findstr /n /i "nyusatsu" WebContent\jsp\supplier\contents\item\data_itemlst.jsp

:: ④ tiles → JSP
> findstr /n /i "id_sup_item_list" WebContent\jsp\layout\*.xml
```

**运行期（Tomcat 用 Debug 启动）**：
| 断点 | 能看到什么 |
|---|---|
| `BaseAction.getAssociateServiceName`（rug_web.jar） | URL → servicename 的映射过程 |
| `NyusatsuIchiranService.java:124` `execute` | ★ **form Map 里到底有什么**（表单字段 + 用户信息 + Locale） |
| `NyusatsuIchiranService.java:562` | `nyusatsuForm` 条件、`nyusatsuMap` 结果 |
| `NyusatsuIchiranEntity.java:483` `dao.select` | ★ **最终 SQL 原文 + 参数数组**（最值得看的一行） |
| `NyusatsuIchiranService.java:685` | forward 名 |

**日志**（`${log.home}/ebid-web.log`，本来就是 DEBUG）：
```
● NyusatsuIchiranService start
● NyusatsuIchiranEntity.getNyusatsuIraiList start
● SIMEI                          ← HD_KUBUNCODE
● NyusatsuIchiranService end
```

---

## 7. 速记卡

```
点检索
 → button_itemlst.jsp:206 Submit_Form()
 → item.js:31 把条件从 SET_SRCHDATA 搬进 SRCH_ITEM 的 HD_* 隐藏域 → submit
 → data_itemlst.jsp:33 <form action="/to_sup_item_list.do">

struts-config.xml:73 /base = BaseAction + BaseMapActionForm(Map型)
         :3980 /to_sup_item_list → forward "nyusatsuichiran" = id_sup_item_list
action-service.xml:2361 → NyusatsuIchiranService（src 里有，类同名）

【框架】form Map = 请求参数 + 登录用户 + Locale + 时区
【Service】NyusatsuIchiranService
   :136 建 nyusatsuForm（条件）  :148 菜单进入给默认值 / :205 表单提交从 form 拷
   :548 dao.open(DENSI)  :562 调 Entity
【Entity】NyusatsuIchiranEntity
   :244 SqlSet.getSupSql("nyusatsuichiran_select001_s")   SQL片段
   :280 createWherePhrase → 条件值进 paraList（占位符绑定，非空才加）
   :325 getPagingListW → :483 dao.select → List<Map>
   :339 拆成 nyusatsudata / pagedata / recordCount
【Service 回传】:640~680 storeResultBean ×8  :685 setForwardString("nyusatsuichiran")  :693 return dset
【框架】request.setAttribute ×8 → findForward → tiles-supplier.xml:90 id_sup_item_list
        button = button_itemlst.jsp（检索输入区）
        contents= data_itemlst.jsp（★列表 JSP）
【JSP】:30 selectform(回填)  :77 rscount  :185 logic:iterate nyusatsu  :70 sup:page(pageData)

SQL 文本在 supplier-sql-statements.xml（部署资源，仓库外）
```
