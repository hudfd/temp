# `to_sup_docex_history_list.do` 整条链路（从点击到 JSP 到数据库）

> 仓库：`E:/agent/pi/day1109/ebid`
> 页面：サプライヤ 汎用文書交換 → 交換履歴（Supplier DOCEX History）
> ⚠️ 你机器上没有 `rg`，**本文所有命令都给了 Windows cmd 可直接粘贴的版本**（`findstr` / `grep`），全部实测过。

---

## 0. 先看结论（链路全景）

```
菜单/表单提交  to_sup_docex_history_list.do
   │
   │ ① struts-config.xml:4339   path → forward "success" = id_docex_sup_hist（tiles 定义名）
   │ ② action-service.xml:4475  name  → servicename = DocexManagedService
   │                                 + RUG_MANAGED_NAME = exec_supplier_docex_history
   │
   ├─【页面侧】③ tiles-supplier.xml:423  id_docex_sup_hist
   │              contents = /jsp/supplier/contents/docex/data_docexhist.jsp   ★JSP
   │              button   = /jsp/supplier/contents/docex/button_docexhist.jsp
   │              title    = title_sup_kokanrireki
   │           ④ 拼装：base_layout.jsp → base_contents.jsp → title/button/contents
   │
   └─【数据侧】⑤ DocexManagedService → service-locator.xml 别名 → 框架 ManagedService
                  → RUG_MANAGED_NAME=exec_supplier_docex_history
                  → managed-service.xml 里的服务链（仓库外）→ 真正的业务 Service
                  → 应该往 request 放：histry / rscount / selectform / date
```

**页面侧 100% 查得到，数据侧是"仓库外"的断链** —— §6 给了证据和继续查的方法。

---

## 1. 第 0 步：谁发的这个请求

```cmd
:: cmd 版（递归搜所有 jsp/js/xml）
E:\agent\pi\day1109\ebid> findstr /s /n /i "to_sup_docex_history_list" *.jsp *.js *.xml
```
```bash
# Git Bash / grep 版
grep -rn "to_sup_docex_history_list" --include=*.jsp --include=*.js --include=*.xml .
```

实测结果：

| 位置 | 内容 | 说明 |
|---|---|---|
| `WebContent/jsp/layout/menu.xml:141` | `<item ... link="to_sup_docex_history_list.do" />` | **入口：供应商菜单 → 交換履歴** |
| `WebContent/jsp/supplier/contents/docex/data_docexhist.jsp:55` | `<html:form styleId="SRCH_ITEM" action="/to_sup_docex_history_list.do">` | **页面自己的检索表单**（查询/翻页时重新提交同一个 do） |
| `WebContent/jsp/supplier/js/docex/docexhist.js:91,194` | `SRCH_ITEM.action = doPath+"/to_sup_docex_history_list.do"` | JS 检索函数 |
| `WebContent/jsp/supplier/js/docex/docexkian.js:253` | `SHEET_FORM.action = path+"/to_sup_docex_history_list.do"` | 从起案页返回履歴 |
| `WebContent/WEB-INF/struts-config.xml:4339` | `<action path="/to_sup_docex_history_list">` | ① |
| `WebContent/WEB-INF/xml/action-service.xml:4475` | `<action name="/to_sup_docex_history_list">` | ② |

> **经验**：`.do` 被谁调用 → 直接 `findstr /s /n /i "do名字" *.jsp *.js *.xml`。
> 注意 `data_docexhist.jsp` 自己就是提交者（列表页 = 输出页 = 表单页），这种情况最常见。

---

## 2. 第 1、2 步：查两张表（URL → 页面 / URL → Service）

```cmd
> findstr /n /i "to_sup_docex_history_list" WebContent\WEB-INF\struts-config.xml
> findstr /n /i "to_sup_docex_history_list" WebContent\WEB-INF\xml\action-service.xml
```

**① struts-config.xml:4339**
```xml
<!-- サプライヤ 汎用文書交換履歴 -->
<action path="/to_sup_docex_history_list" extends="/base" parameter="role=SDOCEX">
    <forward name="success" path="id_docex_sup_hist"/>   ← 不是 .jsp，是 tiles 定义名
</action>
```
`role=SDOCEX` = 权限角色（サプライヤ 汎用文書交換）。

**② action-service.xml:4475**
```xml
<action name="/to_sup_docex_history_list">
    <servicename value="DocexManagedService" />
    <service-param>
        <property key="form" RUG_MANAGED_NAME="exec_supplier_docex_history" />
    </service-param>
</action>
```
- `servicename` = 要执行的 Service 名
- `RUG_MANAGED_NAME` = 传给 ManagedService 的"表单名"（= 服务链的配置 key）

---

## 3. 第 3 步：tiles 定义 → 真正的 JSP

```cmd
> findstr /n /i "id_docex_sup_hist" WebContent\jsp\layout\*.xml
```
```bash
grep -n -A8 "id_docex_sup_hist" WebContent/jsp/layout/*.xml
```

**tiles-supplier.xml:423**
```xml
<definition name="id_docex_sup_hist" extends="sup.bid.base">
    <put name="id"       value="id_docex_sup_hist" />
    <put name="head_key" value="menu.label.title" />
    <put name="head_base" value="SupplierResources" />
    <put name="title"    value="title_sup_kokanrireki" />
    <put name="button"   value="/jsp/supplier/contents/docex/button_docexhist.jsp" />   ← 按钮条
    <put name="contents" value="/jsp/supplier/contents/docex/data_docexhist.jsp" />     ← ★主体 JSP
</definition>
```

### 拼装链（`extends` 继承 + `put` 覆盖）

```
id_docex_sup_hist                                tiles-supplier.xml:423
  └ extends sup.bid.base                         tiles-supplier.xml:135
        put app_style=/jsp/supplier/sup_style.jsp
        put sub_menu=id_sup_bid_menu
        put error=/jsp/common/error.jsp
       └ extends default.base                    tiles-defs.xml:9
             path = /jsp/layout/base_layout.jsp   ← 最外层"画框"
             put body = /jsp/layout/base_contents.jsp
```

运行时逐层输出：

| 步骤 | 文件:行 | 做什么 |
|---|---|---|
| 1 | `base_layout.jsp:203` | `<tiles:insert attribute='body'>` → `base_contents.jsp` |
| 2 | `base_contents.jsp:23` | `<tiles:insert attribute='title'>` → `base_title.jsp`（用 `title_sup_kokanrireki` 的 TITLE_ITEM） |
| 3 | `base_contents.jsp:28` | `<tiles:insert attribute='button'>` → **`button_docexhist.jsp`** |
| 4 | `base_contents.jsp:36` | `<tiles:insert attribute='contents'>` → **`data_docexhist.jsp`** ★ |

**答案：主体 JSP = `WebContent/jsp/supplier/contents/docex/data_docexhist.jsp`**
（头部注释 `data_docexhist.jsp:3 画面名：/jsp/supplier/contents/docex/data_docexhist.jsp` 自证）

`title_sup_kokanrireki`（tiles-supplier.xml:158）里有一项：
```xml
<item value="WRITE" link="date" icon="nowstdate" />
```
→ `base_title.jsp:104` `<bean:write name="date" property="nowstdate"/>`
→ **说明 Service 必须往 request 放一个叫 `date` 的 bean**（这是从"标题"反推数据要求的例子）。

---

## 4. 第 4 步：JSP 到底要哪些数据（对账表）

`data_docexhist.jsp` 里出现的 request attribute：

| JSP 写法 | 行号 | 作用 | 谁该写它 |
|---|---|---|---|
| `<bean:define id="map" name="selectform">` | `:32` | 检索条件回填（`map.OFFERCODE` 等） | Service `storeResultBean("selectform", ...)` |
| `<bean:write name="rscount" property="recordCount">` | `:46`、`:100` | 总件数、CSV 下载按钮 | `storeResultBean("rscount", ...)` |
| `<logic:notEmpty name="histry">` + `<logic:iterate id="item" name="histry">` | `:68`、`:203-204` | **列表数据本体**（`BUNSYO_NO/KENMEI/DOC_STATUS/CT/KOUKAN_KUBUN_NAME...`） | `storeResultBean("histry", list)` |
| 标题里的 `date` | 经 `base_title.jsp:104` | 现在时刻 | `storeResultBean("date", map)` |
| 隐藏域 `beanName=DOCEX_IRAI_JOHO` | `:563` | 点"参照"时跳详情页用的 bean 名 | `storeResultBean("DOCEX_IRAI_JOHO", ...)`（起案详情画面用） |

**对账方法**（在本仓库验证"谁写这些 bean"）：
```cmd
> findstr /s /n /i "histry" src\*.java
> findstr /s /n /i "rscount" src\*.java
```
```bash
grep -rn 'storeResultBean("histry"'  --include=*.java src     ← 无结果
grep -rn 'storeResultBean("rscount"' --include=*.java src     ← 有结果，但都不是 docex 的
grep -rn 'storeResultBean("selectform"' --include=*.java src  ← 有结果，但都不是 docex 的
```

实测：`histry` 在本仓库 **一个都没有**；`rscount`/`selectform` 只出现在
`AnkenSakuteiService`、`KokaiIchiranService`、`NyusatsuIchiranService` 等**别的画面**的 Service 里。
→ **证明这些数据不是本仓库的代码写的**，引出 §6。

---

## 5. 第 5 步：Service 名 → 类（★ 你贴的这段配置是关键）

你找到的这段（**不在 ebid 仓库里**：我 grep 过 `ebid/WebContent/WEB-INF/xml/service-locator.xml` 没有它，
而且那份里 `ManagedService` 那行是被注释掉的，见 `:25-26`，末尾只有兜底规则 `:99 <service name=".*" reference="Remote_Ebid"/>`）：

```xml
<service name="DocexManagedService" type="standalone"
         classname="jp.co.toshiba_sol.wakaba.web.service.ManagedService" />
```

**含义：`DocexManagedService` 根本不是一个业务类，它是框架 `ManagedService` 的“别名”**
（`type="standalone"` = 在本进程内直接 new 后面 `classname` 指定的类）。

这一下解释了两件事：

1. 为什么 `findstr /s /n /i "class DocexManagedService" src\*.java` 什么都搜不到 —— **它压根没有 class**
2. 我之前说的“Service 名 == 类简单名”**只适用于没在 service-locator.xml 登记的服务**

### 服务名 → 类的完整规则（三条，按优先级）

| service-locator.xml 里怎么写 | 怎么解析 | 例子 |
|---|---|---|
| `type="standalone" classname="X"` | **本进程直接 new X** | `DocexManagedService` → `wakaba.web.service.ManagedService`（rug_web.jar） |
| `type="manager" reference="RemoteXxx"` | **RMI 到 RemoteXxx 服务器** | `DmsEntryService` → `RemoteDocument`；`DocexMitumoriExcelDLService` → `Remote_Docex` |
| **没登记**（落到 `.*`） | RMI 到 `Remote_Ebid`，服务端按**类简单名同名**实例化 | `OsatsuShosaiService` → `src/.../OsatsuShosaiService.java` |

→ **本链路真正的执行者 = `jp.co.toshiba_sol.wakaba.web.service.ManagedService`**，
和 `/wf_draft`、`/wf_process_display`（`action-service.xml:342/1520`）**用的是同一个框架类**，只是起了个 docex 专用的名字。

于是链路变成：

```
DocexManagedService
  → service-locator.xml 别名 → ManagedService (rug_web.jar)
  → 读 action-service 传进来的 RUG_MANAGED_NAME = "exec_supplier_docex_history"
  → 读 managed-service.xml（ManagedServiceConfigure 的常量）
  → 找到名为 exec_supplier_docex_history 的服务链
  → 里面才是真正干活的 Service：storeResultBean("histry"/"rscount"/"selectform"/"date")
```

**所以下一个要找的文件就是 `managed-service.xml`** —— 和你找到 service-locator.xml 的**同一个目录**。

---

## 6. ⚠️ 本链路的断点：`DocexManagedService` 不在这个仓库

我做过的验证（你可复现）：

| 验证 | 命令 | 结果 |
|---|---|---|
| 源码里有没有 | `grep -rln "class DocexManagedService" src` | ❌ 无 |
| 本 webapp 的 **79 个 jar** 里有没有 | 解压 `WebContent/WEB-INF/lib/*.jar` 后逐个 `grep -rla DocexManagedService` | ❌ 无 |
| 服务链配置 `exec_supplier_docex_history` 在哪 | `grep -rn "exec_supplier_docex_history" .` | ⚠️ 只有 `action-service.xml:4479/4499` 两处，**没有定义它的文件** |
| `RUG_MANAGED_NAME` 由谁读 | 框架 `rug_web.jar` 的 `ManagedServiceConfigure` → 读 **`managed-service.xml`** | ⚠️ **该文件不在仓库**（部署配置） |
| docex 相关工程在哪 | `build.xml:32` `<property name="docex_lib_dir" value="../docex/WebContent/WEB-INF/lib"/>`<br>`build.xml:33` `<property name="rmi_docex_lib_dir" value="../svc/docex/lib"/>` | 👉 **docex 是兄弟工程 `../docex`，本仓库只有 `ebid/`**（`ls E:/agent/pi/day1109` 只有 ebid + 3 个 md） |

**结论**：
1. ✅ **已解决**：`DocexManagedService` 不是 docex 的业务类，而是 `ManagedService` 的**别名**（你贴的 service-locator.xml）
   → 本仓库 grep 不到 class 是正常的，我之前“属于 docex 工程的类”的推测**不对，以此为准**
2. ⏭️ **下一步**：真正干活的代码链在 `RUG_MANAGED_NAME="exec_supplier_docex_history"` 指向的
   **`managed-service.xml`**（`ManagedServiceConfigure` 读的常量，**不在本仓库**）
   → 去你找到 service-locator.xml 的**同一个目录**找它
3. SQL 用 docex 自己的一套：`docex_common.jar` 里有
   `jp/co/toshiba_sol/docex/common/SqlConst.class / SqlSet.class / SqlXMLParser.class`
   → 对应 docex 工程的 `*-sql-statements.xml`（同样不在本仓库）
   （对照：ebid 自己用的是 `jp.co.toshiba_sol.esup.common.SqlSet` → `buyer-sql-statements.xml`）

### 6.1 找到 service-locator.xml 后，接着找 managed-service.xml

```cmd
:: 假设你在 <某个目录> 找到了 service-locator.xml（告诉我路径，我帮你看）
:: 1) 同目录 / 上级找 managed-service.xml
> dir /s /b managed-service.xml

:: 2) 直接搜服务链 key
> findstr /s /n /i "exec_supplier_docex_history" *.xml

:: 3) 找到后，看这个 key 下面挂了哪些服务
::    例：
::    <form name="exec_supplier_docex_history">
::        <before><service><servicename value="XxxInitService"/></service></before>
::        <service><servicename value="DocexHistoryListService"/></service>   ← 真正干活的
::    </form>
:: 4) 拿到真正的 Service 名后，回本仓库（或 docex 工程）找类
> findstr /s /n /i "class DocexHistoryListService" src\*.java
> findstr /s /n /i "storeResultBean" src\*.java | findstr /i histry
```

> 💡 提示：`ManagedService` 除了读 `managed-service.xml`，还会往日志打
> `Managed: execute name=<form名>`，`New_ManagedService` 会打 `#create config(managed-service.xml)`。
> 在 `ebid-web.log` 里搜这两句，能直接看出它加载了哪个配置文件。

### 6.2 手上没有 docex 工程时，怎么在运行期定位

1. **看日志**（`-Dlog.home` 指向的 `ebid-web.log`，本就是 DEBUG）：
   搜 `DocexManagedService`、`exec_supplier_docex_history`、`Managed: execute name=`
2. **断点**（Tomcat 用 Debug 启动）：
   - `BaseAction.getAssociateServiceName`（`rug_web.jar`，没源码也能断）
     → 停下后能看到 `servicename = DocexManagedService`
   - `ManagedService.execute`（`rug_web.jar`）→ 能看到 `form = exec_supplier_docex_history`
3. **看部署目录**：`<Tomcat>/webapps/.../WEB-INF/classes/managed-service.xml`，
   里面 `<action name="/to_sup_docex_history_list">` 或 `<form name="exec_supplier_docex_history">`
   会直接列出真正的服务链

---

## 7. 对照组：买方侧同款页面（完全一样的套路，可交叉验证）

| | 供应商侧（本文主角） | 买方侧 |
|---|---|---|
| URL | `/to_sup_docex_history_list` | `/to_docex_history_list` |
| struts | `struts-config.xml:4339` → `id_docex_sup_hist` | `:4327` → `id_docex_hist` |
| action-service | `:4475` → `DocexManagedService` / `exec_supplier_docex_history` | `:4463` → `DocexManagedService` / `exec_buyer_docex_history` |
| tiles | `tiles-supplier.xml:423` → `data_docexhist.jsp` | `tiles-buyer.xml:1328 id_docex_hist`（extends `buy.history.base`） |
| 买方详情页 | — | `data_docexhist_syosai.jsp:62` `request.getAttribute("DOCEX_IRAI_JOHO")` |

> 同一个 `DocexManagedService` 服务买/卖两侧，只是 `RUG_MANAGED_NAME` 不同。
> **看到对称结构时，两边互相参照是最快的理解方式。**

---

## 8. 复盘：这套 7 步法适用于任何 `.do`

```bat
:: ① 谁发的这个请求
findstr /s /n /i "XXX.do" *.jsp *.js *.xml

:: ② URL → 页面（forward）
findstr /n /i "path=/XXX" WebContent\WEB-INF\struts-config.xml

:: ③ URL → Service
findstr /n /i "name=/XXX" WebContent\WEB-INF\xml\action-service.xml

:: ④ forward 名（不是 .jsp 时）→ tiles 定义 → 内容 JSP
findstr /n /i "forward名" WebContent\jsp\layout\*.xml
::    看 <put name="contents"|"inner1" value="...jsp">  就是要找的 JSP

:: ⑤ Service 类在不在本仓库
findstr /s /n /i "class 服务名" src\*.java

:: ⑥ 谁往 request 放 JSP 用的 bean（拿 JSP 里的 name= 去对）
findstr /s /n /i "storeResultBean" src\*.java

:: ⑦ 对账三件套
::    storeResultBean 的 key  == JSP 的 <bean:write name=...>
::    setForwardString 的值   == struts 的 <forward name=...>
::    servicename             == 类的简单名
```

**三条对上 = 链路闭环；对不上 = 断链（通常就是 docex / WF 框架这类仓库外模块）。**

---

## 9. 本页链路速记卡

```
to_sup_docex_history_list.do
  入口: menu.xml:141（供应商菜单 交換履歴）
        data_docexhist.jsp:55（列表页自己的检索表单）
        docexhist.js:91 / docexkian.js:253

  struts-config.xml:4339  → forward "success" = id_docex_sup_hist
       └ tiles-supplier.xml:423
            button  = /jsp/supplier/contents/docex/button_docexhist.jsp
            contents= /jsp/supplier/contents/docex/data_docexhist.jsp   ★JSP
            title   = title_sup_kokanrireki (tiles-supplier.xml:158, 用到 bean "date")
            拼装: sup.bid.base(:135) → default.base(tiles-defs:9) → base_layout.jsp:203
                  → base_contents.jsp:23/28/36 → title/button/contents

  action-service.xml:4475 → DocexManagedService
       + RUG_MANAGED_NAME = exec_supplier_docex_history
       → service-locator.xml 别名注册（你找到的那段）
            classname = jp.co.toshiba_sol.wakaba.web.service.ManagedService   ← 框架类，不是业务类
       → ManagedService 读 managed-service.xml（仓库外）
            里的 exec_supplier_docex_history 服务链 → 真正的业务 Service
       → 该 Service 用 docex 的 SqlSet/SqlConst → *-sql-statements.xml（仓库外）

  JSP 要的数据: histry(列表) / rscount(件数) / selectform(检索条件) / date(当前时间)
       → 本仓库 grep 不到 storeResultBean("histry")，证实数据来自 docex 侧
```
