# content_stdind_dsnapp.jsp 数据流转说明

> 对象文件：`ebid/WebContent/jsp/buyer/sheet/sekkei/indent/common/content_stdind_dsnapp.jsp`
> （機能：ワークフロー 入札依頼インデント品 設計承認・输出管理承認）
> 仓库根目录：`E:/agent/pi/day1109`，代码在 `ebid/` 下。
> 本文所有行号都是当前仓库的实际行号，可直接用 `rg -n "关键字"` 复核。

---

## 0. 结论（先看这段）

这个 JSP **自己不查数据库**，它只负责把 request 里已经放好的 Bean 渲染出来。
数据是 **"Action → action-service.xml → Service → Entity → SQL(XML) → DB"** 这条链路
在进入 JSP 之前就塞进 request 的。

JSP 里用到的 request attribute 及其（在本仓库中能确认的）来源：

| JSP 里用的名字 | 谁写进去的（storeResultBean） | 最终来源 |
|---|---|---|
| `NYUSATSUJOHO_UP`（主数据 Map，几乎所有字段） | `StdIndNyusatsuIraiJohoService` / `RirekiNyusatsuIraiJohoService` | `BidIraiEntity.getDispNyusatsuIraiJoho()` → SQL `irai_select01(+01/02)` → 見積依頼テーブル `BID_IRAI`(+Locale) |
| `kiboJuchuInfo`（見積希望サプライヤ列表） | 同上 | `BidRequestEntity.getJuchuInfo()/getJuchuList()` → SQL `request_select01/02` → 希望受注者テーブル |
| `juchuInfo`（受注者） | 同上 | `BidJuchuEntity` → SQL `juchu_select01/02` → `BID_CHOOSE_JUCHU` 系 |
| `nyusatu`（`STATUS_FLAG`，見積内訳按钮状态，JSP:482） | 同上 | `MeisaiTblEntity.getStatus()` → 硬编码 SQL → `BID_MEISAI_TBL` |
| `COMMENT_MAP`（見積取消コメント，JSP:84-92） | `RirekiNyusatsuIraiJohoService:446` | `TaskRirekiKensakuEntity.getCancelComment()` → SQL `cancel_comment_select01` |
| `HaveBuyerDoc`（仕様書有无，JSP:515） | `DMSTranslatorHelper:1372`（Action 前后的 Translator） | DMS 文書サーバ（`RemoteDocument` RMI） |
| `wfDraftInfMap`（JSP:458，SHEET_ID/ORIGINAL_APP_EVENT_ID…） | WF 框架 `SheetDisplayService`（`esup_wf2.jar`） | ワークフロー定義テーブル（ELW/RUG 側 DB） |
| `CommonDataSet`（`PCMTID`）、`BaseActionForm`（`UsedLocaleKey`） | 框架 | 会话/框架 |
| `NYUSATSUJOHO_UP` 的隐藏域（KAIHATSU、HINMEI_CD…） | 同第 1 行（表单回填用） | 同上 |

**JSP 侧证据**（可直接打开文件核对）：

- `content_stdind_dsnapp.jsp:142` `<bean:write name="NYUSATSUJOHO_UP" property="NYUSATSU_NO" ...>`
- `:183` `<logic:iterate id="element" name="kiboJuchuInfo">`
- `:84-92` `COMMENT_MAP/CANCEL_COMMENT`
- `:458` `request.getAttribute("wfDraftInfMap")`
- `:482` `request.getAttribute("nyusatu")` → `STATUS_FLAG`
- `:515-519` `HaveBuyerDoc`
- `:430` 等大量 `<html:hidden name="NYUSATSUJOHO_UP" property="..."/>`

---

## 1. 这个 JSP 是被谁包含的（页面定位）

JSP 文件名要先拿去 `tiles-*.xml` 里反查 tiles 定义：

```
rg -n "content_stdind_dsnapp" ebid/WebContent/jsp/layout/
```

结果（两处）：

**① 登録系（申请/设计承认等操作画面）**
- `tiles-buyer.xml:709` `<definition name="stdind_dsnapp.base" extends="sheet.base">` → inner1 = 本 JSP
- `tiles-buyer.xml:721` `<definition name="buyer_stdind_dsnapp" extends="stdind_dsnapp.base"/>`

**② 進捗内容表示（进度列表里点"内容表示"弹窗，只读）**
- `tiles-buyer.xml:344` `<definition name="stdind_expapp_dsp.base">` → inner1 = 本 JSP
- `tiles-buyer.xml:356` `<definition name="buyer_stdind_expapp_dsp" extends="stdind_expapp_dsp.base"/>`

也就是说：**同一个 JSP 被两个 tiles 定义复用**，一个用于操作画面，一个用于进度查看弹窗。

### 1.1 入口 A：登録系（操作画面）

事件 → 定义 的映射写在 `tiles-defs.xml`：

- `tiles-defs.xml:73` `register.base` 里的 `SHEET_LIST = 0001…0004…`
- `tiles-defs.xml:137` `putList name="sheet_0004"`（入札依頼 インデント品）
  - `:139` `<item value="BRI_EVENT02" link="buyer_stdind_dsnapp" />` ← **设计承认事件**
  - `:140` `BRI_EVENT03 → buyer_stdind_expapp`（输出管理承认）

消费方：
- `base_layout.jsp:107-131`：用 `SHEET_LIST` + `sheet_<SHEET_ID>` 拼出 `FORWARD_SHEET_MAP`（application scope）
- `workflow/contents/data_forward.jsp:27-50`：`wfDraftInfMap.SHEET_ID` + `ORIGINAL_APP_EVENT_ID`
  → `FORWARD_SHEET_MAP[sheetId][eventId]` → `<tiles:insert definition="buyer_stdind_dsnapp"/>`

所以入口 A 的链路是：

```
浏览器 (flow.js / flowcommon.js 提交 COMMON_WF_INFO)
  → struts action  /wf_draft  (struts-config.xml)        [起票/承认画面]
  → action-service.xml:342  servicename=ManagedService, RUG_MANAGED_NAME="exec_wf_draft"
  → WF 框架 DraftService/SheetDisplayService 填充 wfDraftInfMap 等
  → forward "success" = id_wf_draft (register.base)
  → data_forward.jsp → FORWARD_SHEET_MAP → tiles: buyer_stdind_dsnapp
  → inner1 = content_stdind_dsnapp.jsp
```

### 1.2 入口 B：進捗内容表示（弹窗只读）

- `workflow/js/flowcommon.js:519`、`flow.js:1327`：`COMMON_WF_INFO.action='wf_process_display.do'`
- `struts-config.xml:1502` `/wf_process_display` → `<forward name="success" path="flow_processdsp"/>`
- `action-service.xml:1520` → `ManagedService`，`RUG_MANAGED_NAME="exec_wf_processdsp"`（:1530）
- `tiles-defs.xml:1574` `flow_processdsp` → `/jsp/workflow/contents/viewer_processdsp.jsp`
- `viewer_processdsp.jsp`：
  - 用 `SHEET_LIST` + `process_<SHEET_ID>` 拼 `FORWARD_PROCESS_MAP`
  - `processDispMap.SHEET_ID` + `ORIGINAL_APP_EVENT_ID` 查出定义名
  - `<tiles:insert definition="<%=sheetType%>"/>`
- `tiles-defs.xml:1649` `putList name="process_0004"`：
  - `:1650-1652` `BRI_EVENT01/02/03 → buyer_stdind_expapp_dsp`
- → `tiles-buyer.xml:344 stdind_expapp_dsp.base` → inner1 = 本 JSP

---

## 2. 后端取数链路（数据到底从哪个表来）

框架约定（`service-locator.xml` 末行）：

```xml
<service name=".*" type="manager" reference="Remote_Ebid" />
```

即：`action-service.xml` 里的 `<servicename value="XxxService"/>`
→ `ServiceLocator.lookup("XxxService")`（`rug_core.jar`）
→ RMI `Remote_Ebid`
→ **按类简单名约定**实例化 `jp.co.toshiba_sol.esup...XxxService`
（仓库内所有 Service 的类名 == servicename，可自行验证）

### 2.1 本画面的 Service（仓库内可确认的两个）

`src/jp/co/toshiba_sol/esup/bid/buyer/service/sekkei/indent/common/StdIndNyusatsuIraiJohoService.java`

```
execute()
 ├─ BidJobEntity.getJobInfo(form)                       // PROCESS_ID → BID_JOB (job_select01)
 │    └─ 取得 NYUSATSU_NO / HATSU_CD / TYOHYO_KBN
 ├─ BidJuchuEntity.getJuchuInfo/getJuchuList            // juchuInfo   (juchu_select01/02)
 ├─ BidRequestEntity.getJuchuInfo/getJuchuList          // kiboJuchuInfo (request_select01/02)
 ├─ BidIraiEntity.getDispNyusatsuIraiJoho(jobInfoMap)   // ★主数据
 │    └─ getNyusatsuIraiJoho()  (BidIraiEntity.java:1054)
 │         └─ SqlSet.getBuyerSql(SqlConst.IRAI_SELECT01) [+IRAI_SELECT01_01/02]
 │         └─ dao.select(sql, params)   DB = Constants.DENSI_DB ("DENSI")
 ├─ MeisaiTblEntity.getStatus(NYUSATSU_NO,"B"/"A")       // → nyusatu (STATUS_FLAG)
 │    └─ 硬编码 SQL: SELECT * FROM BID_MEISAI_TBL WHERE MITSUMORI_NO=...
 ├─ EsupAppSheetUtil.getTaskKbn(SHEET_ID, ORIGINAL_APP_EVENT_ID) → "kinou"
 │    (EsupAppSheetUtil.java:56 STDIND_SHEETID="0004", :148 → 帳票区分 "IS")
 ├─ proKaigaiPageLogic() → IS_KAIGAI / DISP_KAIGAIYO
 └─ dset.storeResultBean(...)
      :319 Constants.NYUSATSUJOHO_UP   (Constants.java:112)
      :321 juchuInfo
      :324 kiboJuchuInfo
      :257 nyusatu
      :326 jsName / :329 setForwardString("success")
```

`src/.../service/shinchokuichiran/RirekiNyusatsuIraiJohoService.java`（進捗一覧侧，字段集几乎一样）：

- `:441` `storeResultBean("NYUSATSUJOHO_UP", …)`
- `:446` `storeResultBean("COMMENT_MAP", taskKensakuEntity.getCancelComment(jobInfoMap), REQUEST)`
- `:210/:220/:427` `kiboJuchuInfo / juchuInfo / nyusatu`
- 之后还会 new 一个 `StdIndHyokaKekkaService` 继续补数据（`:469`）

### 2.2 SQL 定义在哪

```java
SqlSet.getBuyerSql(SqlConst.IRAI_SELECT01)   // SqlSet.java:84
new SqlXMLParser().parse(SqlXMLParser.BUYER_XML)  // BUYER_XML = "/buyer-sql-statements.xml" (SqlXMLParser.java:52)
```

⚠️ **`buyer-sql-statements.xml` 不在本仓库**（classpath 资源，部署时提供）。
仓库里只有 `batch/common/config/common-sql-statements.xml`（common 组 SQL，例如 `job_select06` → `FROM BID_JOB`）。
所以要看真正的 SELECT 文本，需要到部署环境的 `WEB-INF/classes/buyer-sql-statements.xml`（或对应 jar 内资源）去拿。

### 2.3 涉及的表（按 Entity 注释 + 仓库内硬编码 SQL 推断）

| 用途 | 表 | 证据 |
|---|---|---|
| ジョブ情報 | `BID_JOB` | `batch/common/config/common-sql-statements.xml:349 job_select06 … FROM BID_JOB` |
| 見積依頼主数据 | `BID_IRAI` / `BID_IRAI_LOCALE`（含扩展表） | `BidIraiEntity` 注释、`ExtendEntity.BID_IRAI`（BidIraiEntity.java:2223 等） |
| 受注者選択 | `BID_CHOOSE_JUCHU` 系 | `KaitoProc.java:820 … FROM BID_CHOOSE_JUCHU`，SQL key `juchu_select01/02` |
| 希望受注者 | 希望受注者 Locale テーブル | `BidRequestEntity` 注释，SQL key `request_select01/02` |
| 明細/ステータス | `BID_MEISAI_TBL` | `MeisaiTblEntity.java:548` 硬编码 SQL |

DB 连接名：`Constants.DENSI_DB="DENSI"`（电子入札 DB）、`Constants.SYSTEMKANRI_DB="SYSTEMKANRI"`（系统管理 DB）。

---

## 3. ⚠️ 本仓库里"断掉"的那一环（找不到就在这）

我在仓库内做了全量检索（含解压 `WebContent/WEB-INF/lib/*.jar` 后 grep）：

```
rg -n "StdIndNyusatsuIraiJohoService|RirekiNyusatsuIraiJohoService"  → 只有类自身
grep -r "exec_wf_draft|exec_wf_processdsp" 仓库/所有 jar              → 只有 action-service.xml
find . -iname "managed-service.xml"                                    → 不存在
```

结论：

1. `action-service.xml` 里 `/wf_draft`、`/wf_process_display` 走的是 `ManagedService`，
   它读取 **`managed-service.xml`**（`rug_web.jar` 里 `ManagedServiceConfigure` 的常量）。
   **这个文件不在本仓库**，属于部署配置（通常在 `WEB-INF/classes/managed-service.xml`
   或 ELW/WF 侧 webapp，路径参考 `framework-property.xml` 的 `elwpath=/pcmv2std/develop/rug/WF`）。
2. 因此"进度/起草画面这次请求到底调用了哪个 Service（StdInd… 还是 Rireki…）"
   这一步**无法在仓库内静态确定**，只能确定：两个 Service 都会往 request 里写本 JSP 需要的同名 Bean，
   且字段集合完全覆盖 JSP 的使用（含 `COMMENT_MAP` 的只有 `RirekiNyusatsuIraiJohoService`）。

**运行期验证方法（推荐）**：

- 看日志：两个 Service 一进 `execute()` 就打
  `● StdIndNyusatsuIraiJohoService.execute start` / `● RirekiNyusatsuIraiJohoService start`；
  `ManagedService` 会打 `Managed: execute name=...`。刷新画面后 grep 日志即可确定调用者。
- 断点：`StdIndNyusatsuIraiJohoService.execute` 和 `storeResultBean(Constants.NYUSATSUJOHO_UP, ...)`（:319）。
- 到部署机上 `find / -name managed-service.xml`，里面就是 `exec_wf_draft/exec_wf_processdsp` → 具体 Service 的映射。

---

## 4. 通用方法：任意页面怎么找数据来源（教学）

这套项目是"JSP ← tiles ← Struts Action ← action-service ← Service ← Entity ← SQL-XML ← DB"
的固定套路，按下面 6 步走基本不会迷路。

**第 1 步：JSP → tiles 定义**
```bash
rg -n "页面文件名.jsp" ebid/WebContent/jsp/layout/
# 得到 definition 名，如 buyer_stdind_dsnapp / buyer_stdind_expapp_dsp
```

**第 2 步：tiles 定义 → 谁插入它（= 入口 Action）**
```bash
rg -n 'definition name="buyer_stdind_dsnapp"|FORWARD_SHEET_MAP|FORWARD_PROCESS_MAP' ebid/WebContent/jsp
# 登録系: base_layout.jsp 拼 FORWARD_SHEET_MAP → data_forward.jsp insert
# 進捗系: viewer_processdsp.jsp 拼 FORWARD_PROCESS_MAP → insert
# 再回到 tiles-defs.xml 找 sheet_xxxx / process_xxxx 的映射
```

**第 3 步：入口 Action → Service 名**
```bash
rg -n 'path="/xxx"' ebid/WebContent/WEB-INF/struts-config.xml     # forward 到哪个 tiles 定义
rg -n 'name="/xxx"'  ebid/WebContent/WEB-INF/xml/action-service.xml # servicename / translatorclass
# 注意通配: <action path="/buyer_*"> → <forward path="buyer_{1}"/> (struts-config.xml:4497)
```

**第 4 步：Service 名 → Service 类**
```bash
rg -l "class XxxService" ebid/src        # 约定：类简单名 == servicename
```

**第 5 步：Service → request attribute（这就是 JSP 数据的直接来源）**
```bash
rg -n "storeResultBean|setForwardString" ebid/src/.../XxxService.java
# storeResultBean 的第 1 个参数 == JSP 里 <bean:write name="..."> 的 name
# setForwardString 的值     == struts-config.xml 里 <forward name="..."> 的 name
```

**第 6 步：Service → Entity → SQL → 表**
```bash
rg -n "new .*Entity\(|SqlConst\.|SqlSet\.get" ebid/src/.../XxxService.java
rg -n "IRAI_SELECT01 =" ebid/src/jp/co/toshiba_sol/esup/common/SqlConst.java   # key → 小写下划线
rg -n "irai_select01"   <buyer-sql-statements.xml>                            # 部署环境，仓库内没有
# Entity 里直接硬编码的 SQL（如 MeisaiTblEntity）可以直接看到表名
```

### 4.1 完整可验证示例 1：応札結果詳細画面（仓库内全链路闭环）

| 环节 | 位置 |
|---|---|
| JSP | `ebid/WebContent/jsp/buyer/sheet/kanni/indent/common/viewer_indreply_dtl.jsp:44` `<bean:write name="ousatsuKekkaShosai" property="JUCHU_NAME"/>` |
| forward | `struts-config.xml:1381` `/app_indosatsushosai` → `<forward name="OsatsuShosai" path=".../viewer_indreply_dtl.jsp"/>` |
| Service 名 | `action-service.xml:1374` `<servicename value="OsatsuShosaiService"/>` |
| Service 类 | `src/.../bid/buyer/service/common/shosai/OsatsuShosaiService.java` |
| 写 Bean | 同文件 `:153 storeResultBean("ousatsuKekkaShosai", shosaiInfoMap, REQUEST)`、`:159 setForwardString("OsatsuShosai")` ← 与 forward 名对上 |
| Entity | 同文件 `:114 BidOsatsuShosaiEntity.getOusatsuKekkaShoSai(form)` |
| SQL key | `BidOsatsuShosaiEntity.java:111 SqlSet.getBuyerSql(SqlConst.OSATSU_SHOSAI_SELECT01)` |
| 表 | 由 `buyer-sql-statements.xml` 的 `osatsu_shosai_select01` 决定（部署环境） |

> 三处对上（`bean name` == `storeResultBean` 第 1 参数；`setForwardString` == `forward name`；
> `servicename` == 类名），链路就闭环了。

### 4.2 完整可验证示例 2：シリーズ詳細進捗承認（和本 JSP 同属"进捗"一族）

| 环节 | 位置 |
|---|---|
| JSP | `ebid/WebContent/jsp/buyer/common/viewer_srsdetail.jsp:128` `<logic:iterate id="Item" name="seriesnyusatsuIraiJoho">`、`:77 SeriesDetailJoho` |
| forward | `struts-config.xml:2070` `/buy_shinchoseriesdetail` → `<forward name="NyusatsuIraiJoho" path="/jsp/buyer/common/viewer_srsdetail.jsp"/>` |
| Service 名 | `action-service.xml:2095` `<servicename value="RirekiSeriesIraiShosaiJohoService"/>` + `SeriesShinseiDetailInitTranslator` |
| Service 类 | `src/.../service/common/seriesshosai/RirekiSeriesIraiShosaiJohoService.java` |
| 写 Bean | `:151 storeResultBean("seriesnyusatsuIraiJoho", …)`、`:160 storeResultBean("SeriesDetailJoho", …)`、`:190 setForwardString("NyusatsuIraiJoho")` ← 与 forward 名对上 |
| Entity | `:136 TaskRirekiKensakuEntity`（履歴テーブル） |

> 这个例子说明：**进度/履歴类画面的数据大多来自 `TaskRirekiKensakuEntity`（履歴）+ `BidIraiEntity`（主数据）两条线**，
> `content_stdind_dsnapp.jsp` 也是同样的组合（主数据 `NYUSATSUJOHO_UP` + 履歴注釈 `COMMENT_MAP`）。

---

## 5. 命令速查

```bash
cd E:/agent/pi/day1109/ebid

# ① 这个 JSP 被哪些 tiles 定义引用
rg -n "content_stdind_dsnapp" WebContent/jsp/layout/

# ② tiles 定义在哪些事件下被使用（sheet_0004 / process_0004）
rg -n "buyer_stdind_dsnapp|buyer_stdind_expapp_dsp" WebContent/jsp/layout/

# ③ 入口 action 与 forward
rg -n "wf_process_display|wf_draft" WebContent/WEB-INF/struts-config.xml WebContent/WEB-INF/xml/action-service.xml

# ④ 谁往 request 里放 NYUSATSUJOHO_UP（= 本 JSP 主数据的生产者）
rg -n "NYUSATSUJOHO_UP" -g "*.java" src

# ⑤ 某个 Service 往外抛了哪些 Bean（对上 JSP 的 <bean:write name=...>）
rg -n "storeResultBean|setForwardString" src/jp/co/toshiba_sol/esup/bid/buyer/service/sekkei/indent/common/StdIndNyusatsuIraiJohoService.java

# ⑥ SQL key → 实际 SQL 文本（部署环境）
#    SqlConst.java 里 key 是小写下划线，如 IRAI_SELECT01 = "irai_select01"
#    文本在 classpath 的 buyer-sql-statements.xml（本仓库没有）
```

---

## 6. 一句话总结

`content_stdind_dsnapp.jsp` 的数据 = **request 属性 `NYUSATSUJOHO_UP`（+`kiboJuchuInfo`/`nyusatu`/`COMMENT_MAP`/`HaveBuyerDoc`/`wfDraftInfMap`）**，
由 **`StdIndNyusatsuIraiJohoService` / `RirekiNyusatsuIraiJohoService`**（进捗侧）通过
**`BidIraiEntity → SQL irai_select01 → BID_IRAI(見積依頼テーブル)`** 等查询后
用 `dset.storeResultBean(..., REQUEST)` 放进 request；
页面本身只做渲染。唯一无法在仓库内闭环的是
"`/wf_draft`、`/wf_process_display` 的 ManagedService 配置文件 `managed-service.xml` 不在仓库"，
需要到部署环境确认具体调用了哪个 Service（用第 3 节的日志关键字即可）。
